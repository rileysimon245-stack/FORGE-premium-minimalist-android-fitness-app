package com.forge.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import kotlin.math.roundToInt

private typealias Poly = List<Pair<Float, Float>>

private fun P(vararg v: Float): Poly = v.toList().chunked(2).map { it[0] to it[1] }
private fun mir(p: Poly): Poly = p.map { (100f - it.first) to it.second }

private class Reg(val m: M, val polys: List<Poly>)
private fun sym(m: M, p: Poly) = Reg(m, listOf(p, mir(p)))
private fun one(m: M, p: Poly) = Reg(m, listOf(p))

// Simplified vector body in a 100 x 210 coordinate space (stylised silhouette, not a medical atlas).
private val BASE: List<Poly> = listOf(
    P(36f, 32f, 64f, 32f, 70f, 40f, 68f, 70f, 63f, 100f, 37f, 100f, 32f, 70f, 30f, 40f),
    P(29f, 38f, 21f, 38f, 15f, 60f, 15f, 82f, 23f, 83f, 27f, 60f),
    P(15f, 83f, 23f, 84f, 22f, 108f, 17f, 120f, 11f, 118f, 11f, 100f),
    P(37f, 98f, 63f, 98f, 66f, 112f, 50f, 120f, 34f, 112f),
    P(35f, 112f, 50f, 118f, 49f, 150f, 46f, 165f, 36f, 165f, 33f, 140f),
    P(36f, 168f, 46f, 168f, 47f, 185f, 44f, 205f, 38f, 205f, 35f, 185f),
    P(46f, 21f, 54f, 21f, 55f, 31f, 45f, 31f)
).flatMap { listOf(it, mir(it)) }

private val FRONT = listOf(
    sym(M.CHEST, P(37f, 40f, 50f, 42f, 50f, 58f, 40f, 60f, 34f, 54f)),
    sym(M.FRONT_DELT, P(27f, 37f, 35f, 38f, 35f, 52f, 29f, 52f, 24f, 47f)),
    sym(M.BICEPS, P(22f, 54f, 28f, 54f, 26f, 76f, 18f, 78f, 18f, 62f)),
    sym(M.FOREARM, P(14f, 86f, 22f, 86f, 21f, 106f, 16f, 116f, 12f, 112f, 12f, 98f)),
    one(M.ABS, P(44f, 62f, 56f, 62f, 56f, 98f, 44f, 98f)),
    sym(M.OBLIQUES, P(37f, 64f, 43f, 64f, 43f, 96f, 38f, 96f, 35f, 80f)),
    sym(M.QUADS, P(36f, 114f, 49f, 120f, 48f, 150f, 45f, 162f, 38f, 162f, 34f, 138f)),
    sym(M.CALVES, P(37f, 170f, 46f, 170f, 46f, 186f, 43f, 202f, 39f, 202f, 36f, 186f))
)
private val BACK = listOf(
    one(M.TRAPS, P(50f, 28f, 60f, 34f, 64f, 40f, 50f, 56f, 36f, 40f, 40f, 34f)),
    sym(M.REAR_DELT, P(26f, 37f, 35f, 38f, 35f, 50f, 28f, 52f, 24f, 46f)),
    sym(M.LATS, P(33f, 50f, 43f, 56f, 46f, 80f, 40f, 88f, 34f, 72f)),
    sym(M.TRICEPS, P(21f, 52f, 27f, 54f, 25f, 78f, 17f, 80f, 17f, 62f)),
    one(M.LOWER_BACK, P(44f, 84f, 56f, 84f, 57f, 100f, 43f, 100f)),
    sym(M.GLUTES, P(36f, 100f, 49f, 100f, 49f, 118f, 38f, 120f, 34f, 110f)),
    sym(M.HAMSTRINGS, P(35f, 122f, 49f, 122f, 48f, 152f, 44f, 162f, 38f, 162f, 34f, 140f)),
    sym(M.CALVES, P(37f, 170f, 46f, 170f, 46f, 186f, 43f, 202f, 39f, 202f, 36f, 186f))
)

private fun smooth(p: Poly, k: Float): Path {
    val path = Path(); val n = p.size
    fun mx(a: Pair<Float, Float>, b: Pair<Float, Float>) = (a.first + b.first) / 2f * k
    fun my(a: Pair<Float, Float>, b: Pair<Float, Float>) = (a.second + b.second) / 2f * k
    path.moveTo(mx(p[n - 1], p[0]), my(p[n - 1], p[0]))
    for (i in 0 until n) { val c = p[i]; val nx = p[(i + 1) % n]; path.quadraticBezierTo(c.first * k, c.second * k, mx(c, nx), my(c, nx)) }
    path.close(); return path
}

private fun inside(p: Poly, x: Float, y: Float): Boolean {
    var c = false; var j = p.size - 1
    for (i in p.indices) {
        val (xi, yi) = p[i]; val (xj, yj) = p[j]
        if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c
        j = i
    }
    return c
}

@Composable
private fun Body(back: Boolean, shares: Map<M, Double>, selected: M?, onSelect: (M?) -> Unit, modifier: Modifier) {
    val regs = if (back) BACK else FRONT
    val mx = shares.values.maxOrNull() ?: 0.0
    Canvas(modifier.aspectRatio(100f / 210f).pointerInput(back) {
        detectTapGestures { o ->
            val k = size.width / 100f
            val x = o.x / k; val y = o.y / k
            onSelect(regs.lastOrNull { r -> r.polys.any { inside(it, x, y) } }?.m)
        }
    }) {
        val k = size.width / 100f
        BASE.forEach { drawPath(smooth(it, k), Color(0xFF1E2627)); drawPath(smooth(it, k), Color(0xFF334042), style = Stroke(1.5f)) }
        drawCircle(Color(0xFF1E2627), 9f * k, Offset(50f * k, 13f * k))
        regs.forEach { r ->
            val v = shares[r.m] ?: 0.0
            val col = if (mx > 0 && v > 0) C.mint.copy(alpha = (0.2f + 0.7f * (v / mx).toFloat())) else Color(0xFF2A3335)
            r.polys.forEach { pl ->
                val path = smooth(pl, k)
                drawPath(path, col)
                drawPath(path, if (r.m == selected) C.mint else Color(0xFF0B0F10), style = Stroke(if (r.m == selected) 3.5f else 1.2f))
            }
        }
    }
}

@Composable
fun MusclesScreen(vm: AppVm) {
    val s by vm.snap.collectAsState()
    var period by rememberSaveable { mutableIntStateOf(1) }
    var back by rememberSaveable { mutableStateOf(false) }
    var sel by rememberSaveable { mutableStateOf<String?>(null) }
    val byDay = remember(s.workouts, s.wex, s.sets, s.ex, s.kv["weight"]) { loadsByDay(s) }
    val ld = remember(byDay, period) { loads(byDay, period) }
    val total = ld.values.sum()
    val shares = ld.mapValues { if (total > 0) it.value / total * 100 else 0.0 }
    val visible = (if (back) BACK else FRONT).map { it.m }
    val selM = sel?.let { runCatching { M.valueOf(it) }.getOrNull() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Wordmark(); H1("Карта мышц")
        Seg(listOf("Вид спереди", "Вид сзади"), if (back) 1 else 0, { back = it == 1 })
        Seg(listOf("Сегодня", "Неделя", "Месяц", "Всё время"), period, { period = it })
        if (total <= 0) Empty("За выбранный период нет выполненных подходов — карта заполнится после тренировок.")
        Body(back, shares, selM, { sel = it?.name }, Modifier.fillMaxWidth(0.6f).align(Alignment.CenterHorizontally))
        Sec("Проценты — доля оценочной тренировочной нагрузки за период, а не измерение активации, усталости или роста мышц.", 11, color = C.muted)

        selM?.let { m ->
            val rec = recovery(s, byDay, m)
            Card {
                H2(m.ru)
                Sec(if (total > 0) "Доля нагрузки: ${(shares[m] ?: 0.0).roundToInt()}%" else "Доля нагрузки: нет данных", 13, color = C.text)
                if (rec == null) Sec("Недавних тренировок на эту мышцу нет.", 12) else {
                    val d = LocalDate.ofEpochDay(rec.lastDay)
                    Sec("Последняя нагрузка: ${d.dayOfMonth} ${MONTHS[d.monthValue - 1]}", 12)
                    LinearProgressIndicator(progress = { rec.frac.toFloat() }, Modifier.fillMaxWidth().padding(vertical = 4.dp), color = C.mint, trackColor = C.border)
                    Sec("Восстановление ≈ ${(rec.frac * 100).roundToInt()}% (ориентировочная оценка, не медицинский показатель)", 12)
                }
                val recent = s.workouts.filter { it.status == "DONE" }.sortedByDescending { it.epochDay }.flatMap { w ->
                    s.wex.filter { it.workoutId == w.id }.filter { x ->
                        s.exOf(x.exerciseId)?.let { e -> inv(e.involvement).any { it.first == m } } == true && s.sets.any { it.wexId == x.id && it.done }
                    }.map { x -> x.name to w.epochDay }
                }.take(4)
                recent.forEach { (n, dd) -> val d = LocalDate.ofEpochDay(dd); Sec("• $n — ${d.dayOfMonth} ${MONTHS[d.monthValue - 1]}", 12) }
                Spacer(Modifier.height(6.dp))
                FBtn("Сообщить об усталости", { vm.reportFatigue() }, Modifier.fillMaxWidth(), primary = false)
            }
        }

        H2("Мышцы на этом виде")
        visible.distinct().forEach { m ->
            val v = shares[m] ?: 0.0
            Row(Modifier.fillMaxWidth().clickable { sel = m.name }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(m.ru, Modifier.weight(1f), color = if (m == selM) C.mint else C.text, fontSize = 14.sp)
                Text(if (total > 0) "${v.roundToInt()}%" else "—", color = C.sec, fontSize = 14.sp)
            }
            LinearProgressIndicator(progress = { (v / 100.0).toFloat().coerceIn(0f, 1f) }, Modifier.fillMaxWidth(), color = C.mint, trackColor = C.border)
        }
        Sec("Бицепсы, предплечья, косые и передние дельты показаны на виде спереди; трицепсы, задние дельты и спина — на виде сзади. Сумма долей по всем 15 группам = 100%.", 11, color = C.muted)
        Spacer(Modifier.height(12.dp))
    }
}
