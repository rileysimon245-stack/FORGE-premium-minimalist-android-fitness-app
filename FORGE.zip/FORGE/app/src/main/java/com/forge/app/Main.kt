package com.forge.app

import androidx.compose.runtime.saveable.rememberSaveable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ForgeTheme { Root(viewModel()) } }
    }
}

@Composable
fun Root(vm: AppVm) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val s by vm.snap.collectAsState()
    val host = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { host.showSnackbar(it); vm.message = null } }
    val active = s.workouts.firstOrNull { it.status == "ACTIVE" }
    val navColors = NavigationBarItemDefaults.colors(
        selectedIconColor = C.mint, selectedTextColor = C.mint, unselectedIconColor = C.muted, unselectedTextColor = C.muted, indicatorColor = C.bg2
    )
    Scaffold(
        containerColor = C.bg,
        snackbarHost = { if (vm.stack.isEmpty()) SnackbarHost(host) },
        bottomBar = {
            Column {
                if (active != null && vm.stack.isEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().background(C.mintDark).clickable { vm.push(Ov.Session(active.id)) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Тренировка идёт: ${active.name}", color = C.mint, modifier = Modifier.weight(1f))
                        Text("Продолжить", color = C.mint)
                    }
                }
                NavigationBar(containerColor = C.bg2) {
                    val items = listOf("Календарь" to Icons.Default.CalendarMonth, "Тренировки" to Icons.Default.FitnessCenter, "Мышцы" to Icons.Default.AccessibilityNew, "Профиль" to Icons.Default.Person)
                    items.forEachIndexed { i, (l, ic) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l, maxLines = 1) }, colors = navColors)
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> CalendarScreen(vm) { tab = 3 }
                1 -> WorkoutsScreen(vm)
                2 -> MusclesScreen(vm)
                else -> ProfileScreen(vm)
            }
        }
    }
    if (vm.stack.isNotEmpty()) {
        BackHandler { vm.pop() }
        Box(Modifier.fillMaxSize().background(C.bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
            when (val o = vm.stack.last()) {
                is Ov.Session -> SessionScreen(vm, o.id)
                Ov.Editor -> EditorScreen(vm)
                Ov.Gen -> GeneratorScreen(vm)
            }
            SnackbarHost(host, Modifier.align(Alignment.BottomCenter))
        }
    }
}
