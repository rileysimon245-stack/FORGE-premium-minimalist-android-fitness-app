package com.forge.app

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "exercises")
data class ExerciseE(
    @PrimaryKey val id: String, val name: String, val nameEn: String, val category: String,
    val equipment: String, val involvement: String, val bwFactor: Double,
    val sets: Int, val reps: Int, val rest: Int, val instructions: String, val builtIn: Boolean
)

@Entity(tableName = "programs")
data class ProgramE(
    @PrimaryKey val id: String, val name: String, val description: String, val goal: String,
    val status: String, val createdAt: Long, val source: String, val experience: String,
    val sessionMin: Int, val warmup: String, val cooldown: String, val daysJson: String
)

@Entity(tableName = "planned", indices = [Index(value = ["programId", "epochDay", "dayIndex"], unique = true)])
data class PlannedE(
    @PrimaryKey val id: String, val programId: String, val epochDay: Long,
    val dayIndex: Int, val dayName: String, val status: String
)

@Entity(tableName = "workouts")
data class WorkoutE(
    @PrimaryKey val id: String, val epochDay: Long, val programId: String, val plannedId: String,
    val name: String, val status: String, val startedAt: Long, val durationSec: Long, val note: String
)

@Entity(tableName = "wexercises")
data class WExE(
    @PrimaryKey val id: String, val workoutId: String, val exerciseId: String, val name: String,
    val ord: Int, val plannedSets: Int, val plannedReps: Int, val plannedWeight: Double, val rest: Int
)

@Entity(tableName = "sets")
data class SetE(
    @PrimaryKey val id: String, val wexId: String, val idx: Int,
    val reps: Int, val weight: Double, val done: Boolean
)

@Entity(tableName = "kv")
data class KvE(@PrimaryKey val k: String, val v: String)

@Dao
interface ForgeDao {
    @Query("SELECT * FROM exercises ORDER BY name") fun exercises(): Flow<List<ExerciseE>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addExercises(l: List<ExerciseE>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putExercise(e: ExerciseE)
    @Query("DELETE FROM exercises WHERE id=:id AND builtIn=0") suspend fun delExercise(id: String)

    @Query("SELECT * FROM programs ORDER BY createdAt DESC") fun programs(): Flow<List<ProgramE>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putProgram(p: ProgramE)
    @Query("DELETE FROM programs WHERE id=:id") suspend fun delProgram(id: String)

    @Query("SELECT * FROM planned") fun planned(): Flow<List<PlannedE>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putPlanned(p: PlannedE)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addPlanned(l: List<PlannedE>)
    @Query("DELETE FROM planned WHERE programId=:pid AND epochDay>=:from AND status='PLANNED'")
    suspend fun delFuture(pid: String, from: Long)

    @Query("SELECT * FROM workouts") fun workouts(): Flow<List<WorkoutE>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putWorkout(w: WorkoutE)
    @Query("DELETE FROM workouts WHERE id=:id") suspend fun delWorkoutRow(id: String)

    @Query("SELECT * FROM wexercises") fun wex(): Flow<List<WExE>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putWex(w: WExE)
    @Query("DELETE FROM wexercises WHERE id=:id") suspend fun delWex(id: String)
    @Query("DELETE FROM wexercises WHERE workoutId=:wid") suspend fun delWexOf(wid: String)

    @Query("SELECT * FROM sets") fun sets(): Flow<List<SetE>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSet(s: SetE)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSets(l: List<SetE>)
    @Query("DELETE FROM sets WHERE id=:id") suspend fun delSet(id: String)
    @Query("DELETE FROM sets WHERE wexId=:wxid") suspend fun delSetsOfWex(wxid: String)
    @Query("DELETE FROM sets WHERE wexId IN (SELECT id FROM wexercises WHERE workoutId=:wid)")
    suspend fun delSetsOfWorkout(wid: String)

    @Query("SELECT * FROM kv") fun kv(): Flow<List<KvE>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putKv(k: KvE)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putExercises(l: List<ExerciseE>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putPrograms(l: List<ProgramE>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putPlannedAll(l: List<PlannedE>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putWorkouts(l: List<WorkoutE>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putWexs(l: List<WExE>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putKvs(l: List<KvE>)

    @Query("DELETE FROM exercises") suspend fun clearExercises()
    @Query("DELETE FROM programs") suspend fun clearPrograms()
    @Query("DELETE FROM planned") suspend fun clearPlanned()
    @Query("DELETE FROM workouts") suspend fun clearWorkouts()
    @Query("DELETE FROM wexercises") suspend fun clearWex()
    @Query("DELETE FROM sets") suspend fun clearSets()
    @Query("DELETE FROM kv") suspend fun clearKv()
}

@Database(
    entities = [ExerciseE::class, ProgramE::class, PlannedE::class, WorkoutE::class, WExE::class, SetE::class, KvE::class],
    version = 1, exportSchema = true
)
abstract class ForgeDb : RoomDatabase() {
    abstract fun dao(): ForgeDao
}
