package com.forge.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

@Composable
fun WorkoutsScreen(vm: AppVm) {
    var sub by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Wordmark()
        H1("Тренировки")
        Seg(listOf("Программы", "История", "Упражнения"), sub, { sub = it })
        when (sub) {
            0 -> ProgramsTab(vm)
            1 -> HistoryTab(vm)
            else -> ExercisesTab(vm)
        }
    }
}

@Composable
fun ProgramsTab(vm: AppVm) {
    val s by vm.snap.collectAsState()
    var confirm by remember { mutableStateOf<Pair<ProgramE, String>?>(null) }   // program to action ("PAUSED","ARCHIVED","DELETE")
    var activate by remember { mutableStateOf<ProgramE?>(null) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FBtn("Создать вручную", { vm.openNewDraft() }, Modifier.weight(1f))
                FBtn("Сгенерировать", { vm.push(Ov.Gen) }, Modifier.weight(1f), primary = false)
            }
        }
        if (s.programs.isEmpty()) item { Empty("Программ пока нет. Создай свою или сгенерируй — по правилам или с ИИ.") }
        val order = listOf("ACTIVE", "SAVED", "DRAFT", "PAUSED", "ARCHIVED")
        order.forEach { st ->
            val l = s.programs.filter { it.status == st }
            if (l.isNotEmpty()) {
                item { Sec(STATUS_RU[st] ?: st, 12, Modifier.padding(top = 6.dp), C.muted) }
                items(l, key = { it.id }) { p ->
                    var menu by remember { mutableStateOf(false) }
                    val days = p.days()
                    Card(onClick = { vm.openDraft(p) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, color = C.text, fontSize = 16.sp)
                                Sec("${goalRu(p.goal)} · ${if (p.source == "AI") "ИИ" else if (p.source == "RULES") "по правилам" else "вручную"}", 12)
                                Sec(days.joinToString(" · ") { WD[it.weekday - 1] } .ifEmpty { "дни не заданы" } + " · ${STATUS_RU[p.status]}", 12, color = if (p.status == "ACTIVE") C.mint else C.sec)
                            }
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Действия", tint = C.sec) }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(text = { Text("Открыть / редактировать") }, onClick = { menu = false; vm.openDraft(p) })
                                    DropdownMenuItem(text = { Text("Дублировать") }, onClick = { menu = false; vm.duplicate(p) })
                                    if (p.status != "ACTIVE") DropdownMenuItem(text = { Text(if (p.status == "PAUSED") "Возобновить" else "Активировать") }, onClick = {
                                        menu = false
                                        if (s.programs.any { it.status == "ACTIVE" && it.id != p.id }) activate = p else vm.setProgramStatus(p, "ACTIVE", false)
                                    })
                                    if (p.status == "ACTIVE") DropdownMenuItem(text = { Text("Приостановить") }, onClick = { menu = false; confirm = p to "PAUSED" })
                                    if (p.status != "ARCHIVED") DropdownMenuItem(text = { Text("В архив") }, onClick = { menu = false; confirm = p to "ARCHIVED" })
                                    DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; confirm = p to "DELETE" })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    confirm?.let { (p, act) ->
        val title = when (act) { "PAUSED" -> "Приостановить программу?"; "ARCHIVED" -> "Отправить в архив?"; else -> "Удалить программу?" }
        val apply: (Boolean) -> Unit = { rm -> if (act == "DELETE") vm.deleteProgram(p, rm) else vm.setProgramStatus(p, act, rm); confirm = null }
        Confirm(
            title, "Будущие запланированные тренировки программы «${p.name}»: убрать из календаря? История выполненных тренировок не изменится.",
            "Убрать будущие", { apply(true) }, { confirm = null }, "Оставить", { apply(false) }
        )
    }
    activate?.let { p ->
        Confirm("Заменить активную программу?", "Текущая активная программа будет приостановлена, а тренировки «${p.name}» добавятся в календарь.", "Активировать",
            { vm.setProgramStatus(p, "ACTIVE", false); activate = null }, { activate = null })
    }
}

@Composable
fun HistoryTab(vm: AppVm) {
    val s by vm.snap.collectAsState()
    val list = s.workouts.filter { it.status == "DONE" }.sortedWith(compareByDescending<WorkoutE> { it.epochDay }.thenByDescending { it.startedAt })
    if (list.isEmpty()) { Empty("Выполненных тренировок пока нет."); return }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
        items(list, key = { it.id }) { w ->
            val xs = s.wex.filter { it.workoutId == w.id }
            val ss = s.sets.filter { it.done && xs.any { x -> x.id == it.wexId } }
            val vol = ss.sumOf { it.reps * it.weight }
            val d = LocalDate.ofEpochDay(w.epochDay)
            Card(onClick = { vm.push(Ov.Session(w.id)) }) {
                Text(w.name, color = C.text, fontSize = 16.sp)
                Sec("${d.dayOfMonth} ${MONTHS[d.monthValue - 1]} ${d.year} · упражнений: ${xs.size} · подходов: ${ss.size}" + (if (w.durationSec > 0) " · ${w.durationSec / 60} мин" else ""), 12)
                if (vol > 0) Sec("Объём с внешним весом: ${fmt(Math.round(vol).toDouble())} кг", 12, color = C.muted)
            }
        }
    }
}

@Composable
fun ExercisesTab(vm: AppVm) {
    val s by vm.snap.collectAsState()
    var q by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf<ExerciseE?>(null) }
    var adding by remember { mutableStateOf(false) }
    val list = s.ex.filter { it.name.contains(q, true) || it.nameEn.contains(q, true) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TF(q, { q = it }, "Поиск упражнения", Modifier.weight(1f))
            FBtn("＋", { adding = true })
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(list, key = { it.id }) { e ->
                Card(onClick = { detail = e }) {
                    Text(e.name, color = C.text, fontSize = 15.sp)
                    val muscles = inv(e.involvement).joinToString(", ") { it.first.ru }
                    Sec("${EQUIP.firstOrNull { it.first == e.equipment }?.second} · $muscles", 12)
                }
            }
        }
    }
    detail?.let { ExerciseDetail(vm, s, it) { detail = null } }
    if (adding) CustomExerciseDialog(vm) { adding = false }
}

@Composable
fun Spark(values: List<Double>) {
    if (values.size < 2) return
    val mx = values.max(); val mn = values.min()
    Canvas(Modifier.fillMaxWidth().height(56.dp)) {
        val stepX = size.width / (values.size - 1)
        val pts = values.mapIndexed { i, v -> Offset(i * stepX, size.height - 6f - (if (mx == mn) 0.5f else ((v - mn) / (mx - mn)).toFloat()) * (size.height - 12f)) }
        for (i in 0 until pts.size - 1) drawLine(C.mint, pts[i], pts[i + 1], strokeWidth = 3f)
        pts.forEach { drawCircle(C.mint, 4f, it) }
    }
}

@Composable
fun ExerciseDetail(vm: AppVm, s: Snap, e: ExerciseE, onDismiss: () -> Unit) {
    val h = history(s, e.id)
    val pr = prs(h)
    var del by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.elev,
        title = { Text(e.name, color = C.text) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (e.nameEn.isNotBlank()) Sec(e.nameEn)
                Text(e.instructions, color = C.text, fontSize = 14.sp)
                val inv = inv(e.involvement)
                Sec("Основная: ${inv.firstOrNull()?.first?.ru ?: "—"}" + (if (inv.size > 1) " · Вторичные: " + inv.drop(1).joinToString { it.first.ru } else ""), 12)
                Sec("По умолчанию: ${e.sets}×${e.reps}, отдых ${e.rest} с", 12)
                Sec("Доли нагрузки — настраиваемая оценка, не измерение.", 11, color = C.muted)
                H2("Рекорды")
                if (pr == null) Sec("Выполненных подходов пока нет.") else {
                    Sec("Максимальный вес: ${fmt(pr.maxW)} кг (до ${pr.repsAtMax} повт.)")
                    Sec("Максимум повторений: ${pr.maxReps}")
                    Sec("Лучший объём подхода: ${fmt(pr.bestVol)}")
                    if (pr.maxW == 0.0) Sec("Рекорды по весу считаются только при внешнем весе.", 11, color = C.muted)
                }
                if (h.size >= 2) { Sec("Лучший вес по тренировкам", 12); Spark(h.reversed().map { it.sets.maxOf { s -> s.weight } }) }
                h.take(6).forEach { en ->
                    val d = LocalDate.ofEpochDay(en.w.epochDay)
                    Sec("${d.dayOfMonth} ${MONTHS[d.monthValue - 1]}: " + en.sets.joinToString(", ") { "${it.reps}×${fmt(it.weight)}" }, 12)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть", color = C.mint) } },
        dismissButton = { if (!e.builtIn) TextButton(onClick = { del = true }) { Text("Удалить", color = C.coral) } }
    )
    if (del) Confirm("Удалить упражнение?", "Прошлые записи тренировок сохранятся.", "Удалить", { vm.deleteExercise(e.id); del = false; onDismiss() }, { del = false })
}

@Composable
fun CustomExerciseDialog(vm: AppVm, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("PUSH") }
    var eq by remember { mutableStateOf("BODYWEIGHT") }
    var p1 by remember { mutableStateOf("CHEST") }
    var p2 by remember { mutableStateOf("") }
    var bw by remember { mutableStateOf("60") }
    var ins by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val mOpts = M.values().map { it.name to it.ru }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.elev, title = { Text("Своё упражнение", color = C.text) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TF(name, { name = it }, "Название")
                Drop("Категория", CATS, cat, { cat = it })
                Drop("Оборудование", EQUIP, eq, { eq = it; bw = if (it == "DUMBBELL") "0" else "60" })
                Drop("Основная мышца", mOpts, p1, { p1 = it })
                Drop("Вторичная (необязательно)", listOf("" to "нет") + mOpts, p2, { p2 = it })
                TF(bw, { bw = it }, "Вес тела как нагрузка, %", number = true)
                TF(ins, { ins = it }, "Техника (необязательно)", singleLine = false)
                Sec("Нагрузка распределяется: 70% основной и 30% вторичной мышце (100% основной, если вторичной нет).", 11, color = C.muted)
                err?.let { Text(it, color = C.coral, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val b = bw.toIntOrNull()
                if (name.isBlank()) err = "Укажи название"
                else if (b == null || b !in 0..150) err = "Процент веса тела: от 0 до 150"
                else {
                    val invS = if (p2.isEmpty() || p2 == p1) "$p1:1.0" else "$p1:0.7;$p2:0.3"
                    vm.saveExercise(ExerciseE("custom_" + java.util.UUID.randomUUID(), name.trim(), "", cat, eq, invS, b / 100.0, 3, 10, 60, ins, false))
                    onDismiss()
                }
            }) { Text("Сохранить", color = C.mint) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = C.sec) } }
    )
}
