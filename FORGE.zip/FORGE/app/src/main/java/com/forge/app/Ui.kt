package com.forge.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object C {
    val bg = Color(0xFF0B0F10); val bg2 = Color(0xFF101516); val elev = Color(0xFF141A1B)
    val text = Color(0xFFE8ECEA); val sec = Color(0xFF929C9A); val muted = Color(0xFF6E7977)
    val mint = Color(0xFF43D6A0); val mintDark = Color(0xFF193B30); val coral = Color(0xFFE56F79); val border = Color(0xFF263031)
}

@Composable
fun ForgeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.mint, onPrimary = C.bg, background = C.bg, onBackground = C.text,
            surface = C.bg2, onSurface = C.text, surfaceVariant = C.elev, onSurfaceVariant = C.sec,
            outline = C.border, error = C.coral, secondaryContainer = C.mintDark, onSecondaryContainer = C.mint
        ),
        content = content
    )
}

@Composable
fun Wordmark() = Text("FORGE", fontFamily = FontFamily.Serif, fontSize = 28.sp, color = C.text)

@Composable
fun H1(t: String) = Text(t, fontSize = 22.sp, fontFamily = FontFamily.Serif, color = C.text)

@Composable
fun H2(t: String, modifier: Modifier = Modifier) = Text(t, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = C.text, modifier = modifier)

@Composable
fun Sec(t: String, size: Int = 13, modifier: Modifier = Modifier, color: Color = C.sec) = Text(t, fontSize = size.sp, color = color, modifier = modifier)

@Composable
fun FBtn(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, primary: Boolean = true, enabled: Boolean = true) {
    val shape = RoundedCornerShape(10.dp)
    if (primary) Button(
        onClick = onClick, modifier = modifier, enabled = enabled, shape = shape,
        colors = ButtonDefaults.buttonColors(containerColor = C.mint, contentColor = C.bg, disabledContainerColor = C.border, disabledContentColor = C.muted)
    ) { Text(text, fontWeight = FontWeight.Medium, maxLines = 1) }
    else OutlinedButton(
        onClick = onClick, modifier = modifier, enabled = enabled, shape = shape, border = BorderStroke(1.dp, C.border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = C.text)
    ) { Text(text, maxLines = 1) }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.clip(shape).background(if (selected) C.mintDark else Color.Transparent)
            .border(1.dp, if (selected) C.mint else C.border, shape).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, fontSize = 13.sp, color = if (selected) C.mint else C.sec, maxLines = 1) }
}

@Composable
fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Row(modifier.clip(shape).background(C.bg2).border(1.dp, C.border, shape).padding(2.dp)) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(if (i == sel) Color(0xFF2E6B54) else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 8.dp), contentAlignment = Alignment.Center
            ) { Text(o, fontSize = 13.sp, color = if (i == sel) C.text else C.sec, maxLines = 1) }
        }
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val m = modifier.fillMaxWidth().clip(shape).background(C.elev).border(1.dp, C.border, shape)
    Column((if (onClick != null) m.clickable(onClick = onClick) else m).padding(12.dp), content = content)
}

@Composable
fun Empty(text: String) = Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
    Text(text, color = C.muted, fontSize = 14.sp, textAlign = TextAlign.Center)
}

@Composable
fun tfColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = C.mint, unfocusedBorderColor = C.border, focusedTextColor = C.text, unfocusedTextColor = C.text,
    cursorColor = C.mint, focusedLabelColor = C.mint, unfocusedLabelColor = C.sec
)

@Composable
fun TF(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, singleLine: Boolean = true, number: Boolean = false) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = singleLine, modifier = modifier.fillMaxWidth(),
        colors = tfColors(), shape = RoundedCornerShape(10.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else KeyboardType.Text)
    )
}

/** Compact numeric field. Local text resets only when the external value changes. */
@Composable
fun NumField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, decimal: Boolean = false) {
    var t by remember(value) { mutableStateOf(value) }
    BasicTextField(
        value = t, onValueChange = { t = it; onChange(it) }, singleLine = true,
        textStyle = TextStyle(color = C.text, fontSize = 16.sp, textAlign = TextAlign.Center),
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number),
        cursorBrush = SolidColor(C.mint),
        modifier = modifier.height(40.dp).border(1.dp, C.border, RoundedCornerShape(8.dp)),
        decorationBox = { inner -> Box(Modifier.padding(horizontal = 6.dp), contentAlignment = Alignment.Center) { inner() } }
    )
}

@Composable
fun LNum(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, decimal: Boolean = false) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 11.sp, color = C.muted)
        NumField(value, onChange, Modifier.fillMaxWidth(), decimal)
    }
}

@Composable
fun Drop(label: String, options: List<Pair<String, String>>, value: String, onPick: (String) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { open = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, C.border), colors = ButtonDefaults.outlinedButtonColors(contentColor = C.text)
        ) { Text("$label: ${options.firstOrNull { it.first == value }?.second ?: "—"}", maxLines = 1, fontSize = 13.sp) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o.second) }, onClick = { onPick(o.first); open = false }) }
        }
    }
}

@Composable
fun Confirm(title: String, text: String, ok: String, onOk: () -> Unit, onDismiss: () -> Unit, extra: String? = null, onExtra: (() -> Unit)? = null) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.elev, titleContentColor = C.text, textContentColor = C.sec,
        title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = onOk) { Text(ok, color = C.mint) } },
        dismissButton = {
            Row {
                if (extra != null && onExtra != null) TextButton(onClick = onExtra) { Text(extra, color = C.mint) }
                TextButton(onClick = onDismiss) { Text("Отмена", color = C.sec) }
            }
        }
    )
}

@Composable
fun ExercisePicker(s: Snap, onPick: (ExerciseE) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = s.ex.filter { it.name.contains(q, true) || it.nameEn.contains(q, true) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.elev,
        title = { Text("Выбери упражнение", color = C.text) },
        text = {
            Column {
                TF(q, { q = it }, "Поиск")
                Spacer(Modifier.height(8.dp))
                androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(list.size) { i ->
                        val e = list[i]
                        Column(Modifier.fillMaxWidth().clickable { onPick(e) }.padding(vertical = 8.dp)) {
                            Text(e.name, color = C.text, fontSize = 15.sp)
                            Sec(EQUIP.firstOrNull { it.first == e.equipment }?.second ?: e.equipment, 12)
                        }
                        HorizontalDivider(color = C.border)
                    }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть", color = C.sec) } }
    )
}
