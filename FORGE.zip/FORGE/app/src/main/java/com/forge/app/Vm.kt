package com.forge.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.UUID
import kotlin.math.min

sealed class Ov {
    data class Session(val id: String) : Ov()
    object Editor : Ov()
    object Gen : Ov()
}

class AppVm(app: Application) : AndroidViewModel(app) {
    private val db = Room.databaseBuilder(app, ForgeDb::class.java, "forge.db").build()
    private val dao = db.dao()

    @Suppress("UNCHECKED_CAST")
    val snap: StateFlow<Snap> = combine(
        listOf<Flow<List<Any>>>(dao.exercises(), dao.programs(), dao.planned(), dao.workouts(), dao.wex(), dao.sets(), dao.kv())
    ) { a ->
        Snap(
            a[0] as List<ExerciseE>, a[1] as List<ProgramE>, a[2] as List<PlannedE>, a[3] as List<WorkoutE>,
            a[4] as List<WExE>, a[5] as List<SetE>, (a[6] as List<KvE>).associate { it.k to it.v }
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, Snap())

    var message by mutableStateOf<String?>(null)
    val stack = mutableStateListOf<Ov>()
    var draft by mutableStateOf<Draft?>(null)

    // Rest timer (end timestamp is persisted so it survives process death)
    var restEnd by mutableStateOf(0L)
    var restPaused by mutableStateOf(-1L)
    var restTotal by mutableStateOf(0L)

    private fun uid() = UUID.randomUUID().toString()
    private fun today() = LocalDate.now().toEpochDay()
    fun push(o: Ov) { stack.add(o) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.size - 1) }

    private fun io(block: suspend () -> Unit) = viewModelScope.launch {
        try { block() } catch (e: Exception) { message = "Ошибка: ${e.message ?: "не удалось выполнить операцию"}" }
    }

    init {
        io {
            dao.addExercises(SEED)
            val s = snap.first { it.ex.isNotEmpty() }
            restEnd = s.kvS("restEnd", "0").toLongOrNull() ?: 0L
            restPaused = s.kvS("restPaused", "-1").toLongOrNull() ?: -1L
            restTotal = s.kvS("restTotal", "0").toLongOrNull() ?: 0L
            s.programs.filter { it.status == "ACTIVE" }.forEach { dao.addPlanned(schedule(it, today(), 8)) }
        }
    }

    fun setKv(k: String, v: String) { io { dao.putKv(KvE(k, v)) } }

    // ---------- Rest timer ----------
    private fun saveRest() { io { dao.putKv(KvE("restEnd", restEnd.toString())); dao.putKv(KvE("restPaused", restPaused.toString())); dao.putKv(KvE("restTotal", restTotal.toString())) } }
    fun restStart(sec: Int) { if (sec <= 0) return; restTotal = sec * 1000L; restEnd = System.currentTimeMillis() + restTotal; restPaused = -1; saveRest() }
    fun restPause() { if (restEnd > 0) { restPaused = maxOf(0L, restEnd - System.currentTimeMillis()); restEnd = 0; saveRest() } }
    fun restResume() { if (restPaused >= 0) { restEnd = System.currentTimeMillis() + restPaused; restPaused = -1; saveRest() } }
    fun restSkip() { restEnd = 0; restPaused = -1; restTotal = 0; saveRest() }
    fun restReset() { if (restTotal > 0) { restEnd = System.currentTimeMillis() + restTotal; restPaused = -1; saveRest() } }

    // ---------- Sessions ----------
    private suspend fun addWex(wid: String, ord: Int, pe: PlanEx, s: Snap) {
        val e = s.exOf(pe.exId)
        val wxid = uid()
        val w = if (pe.weight == 0.0) lastWeight(s, pe.exId) else pe.weight
        dao.putWex(WExE(wxid, wid, pe.exId, e?.name ?: "Упражнение", ord, pe.sets, pe.reps, pe.weight, pe.rest))
        dao.putSets((0 until pe.sets).map { SetE(uid(), wxid, it, pe.reps, w, false) })
    }

    private fun activeWorkout() = snap.value.workouts.firstOrNull { it.status == "ACTIVE" }

    fun startPlanned(p: PlannedE) {
        val act = activeWorkout()
        if (act != null) {
            message = if (act.plannedId == p.id) null else "Сначала заверши или отмени текущую тренировку"
            push(Ov.Session(act.id)); return
        }
        io {
            val s = snap.value
            val day = s.programs.firstOrNull { it.id == p.programId }?.days()?.getOrNull(p.dayIndex)
            val wid = uid()
            val date = min(p.epochDay, today())
            dao.putWorkout(WorkoutE(wid, date, p.programId, p.id, p.dayName, "ACTIVE", System.currentTimeMillis(), 0, ""))
            day?.ex?.forEachIndexed { i, pe -> addWex(wid, i, pe, s) }
            push(Ov.Session(wid))
        }
    }

    fun startFree(day: Long) {
        val act = activeWorkout()
        if (act != null) { message = "Сначала заверши или отмени текущую тренировку"; push(Ov.Session(act.id)); return }
        io {
            val wid = uid()
            dao.putWorkout(WorkoutE(wid, day, "", "", "Свободная тренировка", "ACTIVE", System.currentTimeMillis(), 0, ""))
            push(Ov.Session(wid))
        }
    }

    fun updateSet(s: SetE) { io { dao.putSet(s) } }
    fun addSet(x: WExE) {
        io {
            val cur = snap.value.sets.filter { it.wexId == x.id }.sortedBy { it.idx }
            val last = cur.lastOrNull()
            dao.putSet(SetE(uid(), x.id, (last?.idx ?: -1) + 1, last?.reps ?: x.plannedReps, last?.weight ?: x.plannedWeight, false))
        }
    }
    fun removeSet(s: SetE) { io { dao.delSet(s.id) } }
    fun removeWex(x: WExE) { io { db.withTransaction { dao.delSetsOfWex(x.id); dao.delWex(x.id) } } }
    fun addExerciseToWorkout(wid: String, e: ExerciseE) {
        io {
            val s = snap.value
            val ord = (s.wex.filter { it.workoutId == wid }.maxOfOrNull { it.ord } ?: -1) + 1
            addWex(wid, ord, PlanEx(e.id, e.sets, e.reps, 0.0, e.rest), s)
        }
    }
    fun setDuration(w: WorkoutE, sec: Long) { io { dao.putWorkout(w.copy(durationSec = sec)) } }

    fun finish(wid: String, note: String, minutes: Int) {
        io {
            val s = snap.value
            val w = s.workouts.first { it.id == wid }
            dao.putWorkout(w.copy(status = "DONE", note = note, durationSec = minutes * 60L))
            s.planned.firstOrNull { it.id == w.plannedId }?.let { dao.putPlanned(it.copy(status = "DONE")) }
            restSkip()
            message = "Тренировка сохранена"
        }
    }

    fun saveNote(w: WorkoutE, note: String) { io { dao.putWorkout(w.copy(note = note)) } }

    fun cancelSession(wid: String) { io { removeWorkout(wid, false); restSkip() } }
    fun deleteWorkout(wid: String) { io { removeWorkout(wid, true); message = "Тренировка удалена" } }

    private suspend fun removeWorkout(wid: String, revertPlan: Boolean) {
        val s = snap.value
        val w = s.workouts.firstOrNull { it.id == wid } ?: return
        db.withTransaction {
            dao.delSetsOfWorkout(wid); dao.delWexOf(wid); dao.delWorkoutRow(wid)
            if (w.plannedId.isNotEmpty()) s.planned.firstOrNull { it.id == w.plannedId }?.let { dao.putPlanned(it.copy(status = "PLANNED")) }
        }
    }

    // ---------- Planned sessions ----------
    fun setPlannedStatus(p: PlannedE, st: String) { io { dao.putPlanned(p.copy(status = st)) } }
    fun movePlanned(p: PlannedE, day: Long) { io { dao.putPlanned(p.copy(epochDay = day)) } }

    // ---------- Programs ----------
    fun validate(d: Draft): String? {
        if (d.name.isBlank()) return "Укажи название программы"
        if (d.days.isEmpty()) return "Добавь хотя бы один тренировочный день"
        if (d.days.any { it.ex.isEmpty() }) return "В каждом дне нужно хотя бы одно упражнение"
        if (d.days.map { it.weekday }.toSet().size != d.days.size) return "Дни недели в программе не должны повторяться"
        if (d.days.any { day -> day.ex.any { it.sets < 1 || it.reps < 1 } }) return "Подходы и повторения должны быть больше нуля"
        return null
    }

    fun openNewDraft() {
        draft = Draft(uid(), true, "", "", "GENERAL", "BEGINNER", 45, "", "", listOf(PDay("День 1", 1, emptyList())), "MANUAL", "SAVED")
        push(Ov.Editor)
    }
    fun openDraft(p: ProgramE) { draft = p.toDraft(); push(Ov.Editor) }

    /** status = target status. Pauses other active programs when activating. Returns error or null. */
    fun saveProgram(d: Draft, status: String): String? {
        validate(d)?.let { return it }
        io {
            val s = snap.value
            val old = s.programs.firstOrNull { it.id == d.id }
            if (status == "ACTIVE") s.programs.filter { it.status == "ACTIVE" && it.id != d.id }.forEach { dao.putProgram(it.copy(status = "PAUSED")) }
            val p = ProgramE(d.id, d.name.trim(), d.description, d.goal, status, old?.createdAt ?: System.currentTimeMillis(), d.source, d.exp, d.sessionMin, d.warmup, d.cooldown, daysToJson(d.days))
            dao.putProgram(p)
            dao.delFuture(p.id, today())          // only future PLANNED rows; history is untouched
            if (status == "ACTIVE") dao.addPlanned(schedule(p, today(), 8))
            message = if (status == "ACTIVE") "Программа активирована, тренировки добавлены в календарь" else "Программа сохранена"
        }
        return null
    }

    fun setProgramStatus(p: ProgramE, st: String, removeFuture: Boolean) {
        io {
            val s = snap.value
            if (st == "ACTIVE") {
                s.programs.filter { it.status == "ACTIVE" && it.id != p.id }.forEach { dao.putProgram(it.copy(status = "PAUSED")) }
                dao.putProgram(p.copy(status = st))
                dao.addPlanned(schedule(p, today(), 8))
            } else {
                dao.putProgram(p.copy(status = st))
                if (removeFuture) dao.delFuture(p.id, today())
            }
        }
    }

    fun duplicate(p: ProgramE) { io { dao.putProgram(p.copy(id = uid(), name = p.name + " (копия)", status = "DRAFT", createdAt = System.currentTimeMillis())) } }
    fun deleteProgram(p: ProgramE, removeFuture: Boolean) {
        io { dao.delProgram(p.id); if (removeFuture) dao.delFuture(p.id, today()) }
    }

    // ---------- Exercises ----------
    fun saveExercise(e: ExerciseE) { io { dao.putExercise(e) } }
    fun deleteExercise(id: String) { io { dao.delExercise(id) } }

    // ---------- Fatigue ----------
    fun reportFatigue() { setKv("fatigueAt", System.currentTimeMillis().toString()); message = "Учтём усталость в оценке восстановления" }

    // ---------- AI generation (secure server proxy; no keys in the app) ----------
    suspend fun generateAi(r: GenReq): Result<Draft> = withContext(Dispatchers.IO) {
        val s = snap.value
        val url = s.kvS("aiUrl").trim()
        if (url.isEmpty()) return@withContext Result.failure(Exception("Адрес ИИ-сервера не указан (Профиль → ИИ-сервер)"))
        try {
            val lib = org.json.JSONArray()
            s.ex.filter { it.equipment in r.equip + "BODYWEIGHT" }.forEach {
                lib.put(JSONObject().put("id", it.id).put("name", it.name).put("category", it.category).put("equipment", it.equipment).put("sets", it.sets).put("reps", it.reps).put("rest", it.rest))
            }
            val req = JSONObject().put("age", r.age).put("experience", r.exp).put("goal", r.goal)
                .put("days", org.json.JSONArray(r.days)).put("minutes", r.minutes).put("boxingDays", org.json.JSONArray(r.boxing))
                .put("limits", r.limits).put("gentle", r.gentle).put("exercises", lib)
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10_000; c.readTimeout = 60_000; c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(req.toString().toByteArray()) }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
            if (code !in 200..299) return@withContext Result.failure(Exception("Сервер ответил ошибкой $code"))
            val j = JSONObject(body)
            val ids = s.ex.associateBy { it.id }
            val daysA = j.getJSONArray("days")
            if (daysA.length() < 1 || daysA.length() > 7) throw Exception("некорректное число дней")
            val days = (0 until daysA.length()).map { i ->
                val o = daysA.getJSONObject(i)
                val wd = o.getInt("weekday"); if (wd !in 1..7) throw Exception("некорректный день недели")
                val ea = o.getJSONArray("exercises")
                PDay(o.getString("name"), wd, (0 until ea.length()).map { k ->
                    val e = ea.getJSONObject(k)
                    val id = e.getString("exId"); if (!ids.containsKey(id)) throw Exception("неизвестное упражнение $id")
                    val sets = e.getInt("sets"); val reps = e.getInt("reps"); val w = e.optDouble("weight", 0.0); val rest = e.optInt("rest", 60)
                    if (sets !in 1..10 || reps !in 1..100 || w < 0 || w > 500 || rest !in 0..600) throw Exception("значения вне допустимых границ")
                    PlanEx(id, sets, reps, w, rest)
                })
            }
            if (days.map { it.weekday }.toSet().size != days.size) throw Exception("повторяются дни недели")
            Result.success(Draft(uid(), true, j.optString("name", "Программа ИИ").ifBlank { "Программа ИИ" }, j.optString("description", ""), r.goal, r.exp, r.minutes,
                j.optString("warmup", ""), j.optString("cooldown", ""), days, "AI", "DRAFT", r))
        } catch (e: java.net.SocketTimeoutException) {
            Result.failure(Exception("Сервер не ответил вовремя"))
        } catch (e: java.io.IOException) {
            Result.failure(Exception("Нет соединения с сервером"))
        } catch (e: Exception) {
            Result.failure(Exception("ИИ вернул некорректный план: ${e.message}"))
        }
    }

    // ---------- Backup ----------
    fun backupJson(): String = exportJson(snap.value)
    fun csv(): String = exportCsv(snap.value)

    suspend fun restore(text: String): String? {
        return try {
            val p = parseBackup(text)
            @Suppress("UNCHECKED_CAST")
            db.withTransaction {
                dao.clearSets(); dao.clearWex(); dao.clearWorkouts(); dao.clearPlanned(); dao.clearPrograms(); dao.clearExercises(); dao.clearKv()
                dao.putExercises(p.tables["exercises"] as List<ExerciseE>)
                dao.putPrograms(p.tables["programs"] as List<ProgramE>)
                dao.putPlannedAll(p.tables["planned"] as List<PlannedE>)
                dao.putWorkouts(p.tables["workouts"] as List<WorkoutE>)
                dao.putWexs(p.tables["wexercises"] as List<WExE>)
                dao.putSets(p.tables["sets"] as List<SetE>)
                dao.putKvs(p.tables["kv"] as List<KvE>)
                dao.addExercises(SEED)
            }
            null
        } catch (e: IllegalArgumentException) { e.message } catch (e: Exception) { "Не удалось восстановить данные: ${e.message}" }
    }
}
