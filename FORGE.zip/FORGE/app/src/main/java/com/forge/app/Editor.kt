package com.forge.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun EditorScreen(vm: AppVm) {
    val d = vm.draft
    if (d == null) { LaunchedEffect(Unit) { vm.pop() }; return }
    val s by vm.snap.collectAsState()
    var picker by remember { mutableStateOf<Pair<Int, Int>?>(null) }   // (day, exercise index to replace or -1 to add)
    var err by remember { mutableStateOf<String?>(null) }
    var confirmActivate by remember { mutableStateOf(false) }
    var confirmRegen by remember { mutableStateOf(false) }
    val existing = s.programs.firstOrNull { it.id == d.id }
    fun upd(n: Draft) { vm.draft = n }
    fun updDay(i: Int, f: (PDay) -> PDay) = upd(d.copy(days = d.days.mapIndexed { k, x -> if (k == i) f(x) else x }))
    fun updEx(di: Int, ei: Int, f: (PlanEx) -> PlanEx) = updDay(di) { day -> day.copy(ex = day.ex.mapIndexed { k, x -> if (k == ei) f(x) else x }) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.pop() }) { Icon(Icons.Default.ArrowBack, "Назад", tint = C.text) }
            H1(if (d.isNew && existing == null) "Новая программа" else "Программа")
        }
        if (d.source != "MANUAL") Sec(if (d.source == "AI") "Сгенерировано ИИ — проверь и отредактируй перед активацией" else "Сгенерировано по правилам (не ИИ) — проверь и отредактируй", 12, color = C.mint)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            item { TF(d.name, { upd(d.copy(name = it)) }, "Название") }
            item { TF(d.description, { upd(d.copy(description = it)) }, "Описание и заметки", singleLine = false) }
            item { Drop("Цель", GOALS, d.goal, { upd(d.copy(goal = it)) }) }
            item { Drop("Опыт", EXPS, d.exp, { upd(d.copy(exp = it)) }) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Sec("Длительность:", 13); listOf(30, 45, 60, 90).forEach { m -> Chip("$m мин", d.sessionMin == m, { upd(d.copy(sessionMin = m)) }) }
                }
            }
            item { TF(d.warmup, { upd(d.copy(warmup = it)) }, "Разминка", singleLine = false) }
            item { TF(d.cooldown, { upd(d.copy(cooldown = it)) }, "Заминка", singleLine = false) }
            d.days.forEachIndexed { di, day ->
                item(key = "day$di") {
                    Card {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { TF(day.name, { n -> updDay(di) { it.copy(name = n) } }, "Название дня") }
                            IconButton(enabled = di > 0, onClick = { upd(d.copy(days = d.days.toMutableList().also { l -> val x = l.removeAt(di); l.add(di - 1, x) })) }) { Icon(Icons.Default.KeyboardArrowUp, "Выше", tint = C.sec) }
                            IconButton(enabled = di < d.days.size - 1, onClick = { upd(d.copy(days = d.days.toMutableList().also { l -> val x = l.removeAt(di); l.add(di + 1, x) })) }) { Icon(Icons.Default.KeyboardArrowDown, "Ниже", tint = C.sec) }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            WD.forEachIndexed { i, w -> Chip(w, day.weekday == i + 1, { updDay(di) { it.copy(weekday = i + 1) } }, Modifier.weight(1f)) }
                        }
                        day.ex.forEachIndexed { ei, pe ->
                            Spacer(Modifier.height(8.dp)); HorizontalDivider(color = C.border); Spacer(Modifier.height(6.dp))
                            val e = s.exOf(pe.exId)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(e?.name ?: "Упражнение удалено", color = C.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                IconButton(enabled = ei > 0, onClick = { updDay(di) { dd -> dd.copy(ex = dd.ex.toMutableList().also { l -> val x = l.removeAt(ei); l.add(ei - 1, x) }) } }) { Icon(Icons.Default.KeyboardArrowUp, "Выше", tint = C.sec) }
                                IconButton(enabled = ei < day.ex.size - 1, onClick = { updDay(di) { dd -> dd.copy(ex = dd.ex.toMutableList().also { l -> val x = l.removeAt(ei); l.add(ei + 1, x) }) } }) { Icon(Icons.Default.KeyboardArrowDown, "Ниже", tint = C.sec) }
                                IconButton(onClick = { picker = di to ei }) { Icon(Icons.Default.SwapHoriz, "Заменить", tint = C.sec) }
                                IconButton(onClick = { updDay(di) { dd -> dd.copy(ex = dd.ex.filterIndexed { k, _ -> k != ei }) } }) { Icon(Icons.Default.Delete, "Удалить", tint = C.sec) }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                LNum("Подходы", pe.sets.toString(), { t -> t.toIntOrNull()?.let { v -> updEx(di, ei) { it.copy(sets = v) } } }, Modifier.weight(1f))
                                LNum("Повт.", pe.reps.toString(), { t -> t.toIntOrNull()?.let { v -> updEx(di, ei) { it.copy(reps = v) } } }, Modifier.weight(1f))
                                LNum("Вес, кг", fmt(pe.weight), { t -> t.replace(',', '.').toDoubleOrNull()?.let { v -> updEx(di, ei) { it.copy(weight = v) } } }, Modifier.weight(1f), decimal = true)
                                LNum("Отдых, с", pe.rest.toString(), { t -> t.toIntOrNull()?.let { v -> updEx(di, ei) { it.copy(rest = v) } } }, Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FBtn("＋ Упражнение", { picker = di to -1 }, Modifier.weight(1f), primary = false)
                            FBtn("Удалить день", { upd(d.copy(days = d.days.filterIndexed { k, _ -> k != di })) }, Modifier.weight(1f), primary = false)
                        }
                        if (d.source == "RULES" && d.req != null) {
                            Spacer(Modifier.height(6.dp))
                            FBtn("Заново сгенерировать этот день", {
                                val g = generate(s, d.req, System.nanoTime())
                                val ng = g.days.getOrNull(di)
                                if (ng != null) updDay(di) { it.copy(ex = ng.ex) } else err = "Не удалось сгенерировать день"
                            }, Modifier.fillMaxWidth(), primary = false)
                        }
                    }
                }
            }
            item {
                val free = (1..7).firstOrNull { w -> d.days.none { it.weekday == w } } ?: 1
                FBtn("＋ Добавить день", { upd(d.copy(days = d.days + PDay("День ${d.days.size + 1}", free, emptyList()))) }, Modifier.fillMaxWidth(), primary = false)
            }
            if (d.req != null) item { FBtn("Заново сгенерировать всю программу", { confirmRegen = true }, Modifier.fillMaxWidth(), primary = false) }
        }
        err?.let { Text(it, color = C.coral, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp)) }
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FBtn(if (d.source == "MANUAL") "Сохранить" else "В черновик", {
                err = vm.saveProgram(d, if (existing != null) existing.status else if (d.source == "MANUAL") "SAVED" else "DRAFT")
                if (err == null) vm.pop()
            }, Modifier.weight(1f), primary = false)
            FBtn(if (existing?.status == "ACTIVE") "Сохранить" else "Активировать", {
                err = vm.validate(d)
                if (err == null) {
                    if (existing?.status == "ACTIVE") { vm.saveProgram(d, "ACTIVE"); vm.pop() }
                    else if (s.programs.any { it.status == "ACTIVE" && it.id != d.id }) confirmActivate = true
                    else { vm.saveProgram(d, "ACTIVE"); vm.pop() }
                }
            }, Modifier.weight(1f))
        }
    }
    picker?.let { (di, ei) ->
        ExercisePicker(s, { e ->
            val pe = PlanEx(e.id, e.sets, e.reps, 0.0, e.rest)
            if (ei < 0) updDay(di) { it.copy(ex = it.ex + pe) } else updEx(di, ei) { old -> pe.copy(weight = old.weight) }
            picker = null
        }, { picker = null })
    }
    if (confirmActivate) Confirm("Заменить активную программу?", "Текущая активная программа будет приостановлена. Ничего не удаляется без подтверждения.", "Активировать",
        { vm.saveProgram(d, "ACTIVE"); confirmActivate = false; vm.pop() }, { confirmActivate = false })
    if (confirmRegen) Confirm("Сгенерировать заново?", "Текущие правки этого черновика будут заменены новым вариантом.", "Заменить",
        { d.req?.let { r -> upd(generate(s, r, System.nanoTime()).copy(id = d.id)) }; confirmRegen = false }, { confirmRegen = false })
}

@Composable
fun GeneratorScreen(vm: AppVm) {
    val s by vm.snap.collectAsState()
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(0) }
    var age by remember { mutableStateOf(s.kvS("age")) }
    var exp by remember { mutableStateOf(s.kvS("exp", "BEGINNER")) }
    var goal by remember { mutableStateOf(s.kvS("goal", "GENERAL")) }
    var equip by remember { mutableStateOf(s.kvS("equip", "BODYWEIGHT").split(",").filter { it.isNotBlank() }.toSet()) }
    var days by remember { mutableStateOf(setOf(1, 3, 5)) }
    var minutes by remember { mutableIntStateOf(45) }
    var boxing by remember { mutableStateOf(setOf<Int>()) }
    var limits by remember { mutableStateOf("") }
    var gentle by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    fun req(): GenReq? {
        val a = age.toIntOrNull()
        if (a == null || a !in 8..90) { err = "Укажи возраст (8–90) на первом шаге"; step = 0; return null }
        if (days.isEmpty()) { err = "Выбери хотя бы один день тренировок"; step = 1; return null }
        err = null
        return GenReq(a, exp, goal, equip + "BODYWEIGHT", days.sorted(), minutes, boxing.sorted(), limits, gentle)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.pop() }) { Icon(Icons.Default.ArrowBack, "Назад", tint = C.text) }
            H1("Генератор программы")
        }
        Sec("Шаг ${step + 1} из 3. Необязательные вопросы можно пропустить.")
        when (step) {
            0 -> {
                TF(age, { age = it }, "Возраст", number = true)
                H2("Опыт"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { EXPS.forEach { (k, v) -> Chip(v, exp == k, { exp = k }) } }
                H2("Главная цель")
                GOALS.forEach { (k, v) -> Chip(v, goal == k, { goal = k }) }
                if ((age.toIntOrNull() ?: 99) < 16) Sec("Для юных спортсменов: акцент на технику, постепенность и восстановление, без проверки максимума.", 12, color = C.mint)
            }
            1 -> {
                H2("Оборудование"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    EQUIP.forEach { (k, v) -> Chip(v, k in equip || k == "BODYWEIGHT", { if (k != "BODYWEIGHT") equip = if (k in equip) equip - k else equip + k }) }
                }
                Sec("Тренажёры не предполагаются — только свой вес, гантели и турник.", 12, color = C.muted)
                H2("Дни тренировок"); Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    WD.forEachIndexed { i, w -> Chip(w, (i + 1) in days, { days = if ((i + 1) in days) days - (i + 1) else days + (i + 1) }, Modifier.weight(1f)) }
                }
                H2("Длительность"); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(30, 45, 60, 90).forEach { m -> Chip("$m мин", minutes == m, { minutes = m }) } }
                H2("Дни бокса / другого спорта (необязательно)"); Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    WD.forEachIndexed { i, w -> Chip(w, (i + 1) in boxing, { boxing = if ((i + 1) in boxing) boxing - (i + 1) else boxing + (i + 1) }, Modifier.weight(1f)) }
                }
            }
            else -> {
                TF(limits, { limits = it }, "Боль, травмы, ограничения (необязательно)", singleLine = false)
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(checked = gentle, onCheckedChange = { gentle = it }); Spacer(Modifier.width(8.dp)); Text("Больше восстановления (меньше подходов)", color = C.text, fontSize = 14.sp) }
                Sec("Недавние результаты берутся из твоего дневника автоматически (рабочие веса подставляются без повышения).", 12, color = C.muted)
            }
        }
        err?.let { Text(it, color = C.coral, fontSize = 13.sp) }
        if (step < 2) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (step > 0) FBtn("Назад", { step-- }, Modifier.weight(1f), primary = false)
            FBtn("Далее", { step++ }, Modifier.weight(1f))
        } else {
            FBtn("Назад", { step-- }, Modifier.fillMaxWidth(), primary = false)
            FBtn("Сгенерировать по правилам (без ИИ)", {
                req()?.let { r -> vm.draft = generate(s, r, System.nanoTime()); vm.pop(); vm.push(Ov.Editor) }
            }, Modifier.fillMaxWidth())
            FBtn(if (loading) "Запрос к ИИ…" else if (err != null && err!!.startsWith("ИИ") || err?.startsWith("Сервер") == true || err?.startsWith("Нет") == true) "Повторить запрос к ИИ" else "Сгенерировать с ИИ", {
                req()?.let { r ->
                    loading = true; err = null
                    scope.launch {
                        val res = vm.generateAi(r)
                        loading = false
                        res.onSuccess { dr -> vm.draft = dr; vm.pop(); vm.push(Ov.Editor) }.onFailure { e -> err = e.message }
                    }
                }
            }, Modifier.fillMaxWidth(), primary = false, enabled = !loading)
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = C.mint)
            if (s.kvS("aiUrl").isBlank()) Sec("ИИ-сервер не настроен (Профиль → ИИ-сервер). Офлайн-генератор работает без интернета.", 12, color = C.muted)
        }
        Spacer(Modifier.height(16.dp))
    }
}
