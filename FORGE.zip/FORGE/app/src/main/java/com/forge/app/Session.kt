package com.forge.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

fun mmss(sec: Long): String = "%02d:%02d".format(sec / 60, sec % 60)

@Composable
fun SessionScreen(vm: AppVm, wid: String) {
    val s by vm.snap.collectAsState()
    val w = s.workouts.firstOrNull { it.id == wid }
    if (w == null) { LaunchedEffect(Unit) { vm.pop() }; return }
    val active = w.status == "ACTIVE"
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(250) } }
    var picker by remember { mutableStateOf(false) }
    var finish by remember { mutableStateOf(false) }
    var cancel by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    var note by remember(w.id) { mutableStateOf(w.note) }
    val xs = s.wex.filter { it.workoutId == wid }.sortedBy { it.ord }
    val allSets = s.sets.filter { st -> xs.any { it.id == st.wexId } }
    val doneN = allSets.count { it.done }
    val remaining = if (vm.restPaused >= 0) vm.restPaused else maxOf(0L, vm.restEnd - now)
    val restOn = vm.restEnd > 0 || vm.restPaused >= 0
    LaunchedEffect(remaining, restOn) { if (restOn && vm.restPaused < 0 && vm.restEnd in 1..now) vm.restSkip() }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.pop() }) { Icon(Icons.Default.ArrowBack, "Назад", tint = C.text) }
            Column(Modifier.weight(1f)) {
                Text(w.name, fontSize = 18.sp, fontFamily = FontFamily.Serif, color = C.text, maxLines = 1)
                Sec(if (active) "Время: ${mmss(maxOf(0L, (now - w.startedAt) / 1000))}" else "Редактирование записи", 12)
            }
        }
        LinearProgressIndicator(progress = { if (allSets.isEmpty()) 0f else doneN / allSets.size.toFloat() }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), color = C.mint, trackColor = C.border)
        Sec("Выполнено подходов: $doneN из ${allSets.size}", 12)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Spacer(Modifier.height(4.dp))
            if (restOn) Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Sec("Отдых", 12); Text(mmss((remaining + 999) / 1000), fontSize = 28.sp, fontFamily = FontFamily.Serif, color = C.mint) }
                    if (vm.restPaused >= 0) IconButton(onClick = { vm.restResume() }) { Icon(Icons.Default.PlayArrow, "Продолжить", tint = C.mint) }
                    else IconButton(onClick = { vm.restPause() }) { Icon(Icons.Default.Pause, "Пауза", tint = C.text) }
                    IconButton(onClick = { vm.restReset() }) { Icon(Icons.Default.Refresh, "Сброс", tint = C.text) }
                    IconButton(onClick = { vm.restSkip() }) { Icon(Icons.Default.SkipNext, "Пропустить", tint = C.text) }
                }
            }
            if (xs.isEmpty()) Empty("Упражнений нет. Добавь упражнение ниже.")
            xs.forEach { x ->
                val sets = s.sets.filter { it.wexId == x.id }.sortedBy { it.idx }
                val ex = s.exOf(x.exerciseId)
                val last = history(s, x.exerciseId, wid).firstOrNull()
                var info by remember(x.id) { mutableStateOf(false) }
                Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(x.name, color = C.text, fontSize = 16.sp)
                            Sec("План: ${x.plannedSets}×${x.plannedReps}" + (if (x.plannedWeight > 0) " · ${fmt(x.plannedWeight)} кг" else "") + " · отдых ${x.rest} с", 12)
                            if (last != null) Sec("Прошлый раз: " + last.sets.joinToString(", ") { "${it.reps}×${fmt(it.weight)}" }, 12, color = C.muted)
                        }
                        IconButton(onClick = { info = !info }) { Icon(Icons.Default.Info, "Техника", tint = C.sec) }
                        IconButton(onClick = { vm.removeWex(x) }) { Icon(Icons.Default.Delete, "Удалить упражнение", tint = C.sec) }
                    }
                    if (info && ex != null) Sec(ex.instructions, 12, color = C.text)
                    Spacer(Modifier.height(6.dp))
                    sets.forEachIndexed { i, st ->
                        Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${i + 1}", Modifier.width(20.dp), color = C.muted)
                            LNum("Повт.", st.reps.toString(), { t -> t.toIntOrNull()?.let { v -> if (v >= 0) vm.updateSet(st.copy(reps = v)) } }, Modifier.weight(1f))
                            LNum("Вес, кг", fmt(st.weight), { t -> t.replace(',', '.').toDoubleOrNull()?.let { v -> if (v >= 0) vm.updateSet(st.copy(weight = v)) } }, Modifier.weight(1f), decimal = true)
                            Checkbox(checked = st.done, onCheckedChange = { ch ->
                                vm.updateSet(st.copy(done = ch))
                                if (ch && active) vm.restStart(x.rest)
                            }, colors = CheckboxDefaults.colors(checkedColor = C.mint, checkmarkColor = C.bg, uncheckedColor = C.muted))
                            IconButton(onClick = { vm.removeSet(st) }, Modifier.size(32.dp)) { Icon(Icons.Default.Close, "Удалить подход", tint = C.muted) }
                        }
                    }
                    if (sets.isNotEmpty() && sets.all { it.done && it.reps >= x.plannedReps } && x.plannedWeight >= 0 && ex != null && ex.equipment == "DUMBBELL") {
                        Sec("Все подходы выполнены. Можно рассмотреть +1–2 кг в следующий раз — решение за тобой.", 11, color = C.mint)
                    }
                    TextButton(onClick = { vm.addSet(x) }) { Text("＋ Подход", color = C.mint) }
                }
            }
            FBtn("Добавить упражнение", { picker = true }, Modifier.fillMaxWidth(), primary = false)
            if (!active) {
                TF(note, { note = it }, "Заметка", singleLine = false)
                FBtn("Сохранить заметку", { vm.saveNote(w, note); vm.message = "Заметка сохранена" }, Modifier.fillMaxWidth(), primary = false)
                FBtn("Удалить тренировку", { del = true }, Modifier.fillMaxWidth(), primary = false)
            }
            Spacer(Modifier.height(8.dp))
        }
        if (active) Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FBtn("Отменить", { cancel = true }, Modifier.weight(1f), primary = false)
            FBtn("Завершить", { if (doneN == 0) vm.message = "Отметь хотя бы один выполненный подход" else finish = true }, Modifier.weight(1f))
        }
    }

    if (picker) ExercisePicker(s, { vm.addExerciseToWorkout(wid, it); picker = false }, { picker = false })
    if (cancel) Confirm("Отменить тренировку?", "Записанные подходы будут удалены, тренировка не засчитается.", "Отменить тренировку", { cancel = false; vm.cancelSession(wid); vm.pop() }, { cancel = false })
    if (del) Confirm("Удалить тренировку?", "Статистика, рекорды и карта мышц пересчитаются.", "Удалить", { del = false; vm.deleteWorkout(wid); vm.pop() }, { del = false })
    if (finish) {
        var fnote by remember { mutableStateOf(w.note) }
        var mins by remember { mutableStateOf(maxOf(1L, (System.currentTimeMillis() - w.startedAt) / 60000).toString()) }
        val done = allSets.filter { it.done }
        val vol = done.sumOf { it.reps * it.weight }
        val records = xs.mapNotNull { x ->
            val prior = history(s, x.exerciseId, wid).flatMap { it.sets }.maxOfOrNull { it.weight } ?: 0.0
            val now = done.filter { it.wexId == x.id && it.reps > 0 }.maxOfOrNull { it.weight } ?: 0.0
            if (prior > 0 && now > prior) "${x.name}: ${fmt(now)} кг (было ${fmt(prior)})" else null
        }
        AlertDialog(
            onDismissRequest = { finish = false }, containerColor = C.elev, title = { Text("Итоги тренировки", color = C.text) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Sec("Упражнений: ${xs.size} · выполнено подходов: ${done.size} из ${allSets.size}", 13, color = C.text)
                    Sec("Объём с внешним весом: ${fmt(Math.round(vol).toDouble())} кг", 13, color = C.text)
                    records.forEach { Text("Новый рекорд — $it", color = C.mint, fontSize = 13.sp) }
                    TF(mins, { mins = it }, "Длительность, мин", number = true)
                    TF(fnote, { fnote = it }, "Заметка", singleLine = false)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val m = mins.toIntOrNull()
                    if (m == null || m < 1) vm.message = "Укажи длительность в минутах"
                    else { vm.finish(wid, fnote, m); finish = false; vm.pop() }
                }) { Text("Сохранить", color = C.mint) }
            },
            dismissButton = { TextButton(onClick = { finish = false }) { Text("Назад", color = C.sec) } }
        )
    }
}
