package com.forge.app

import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class M(val ru: String) {
    CHEST("Грудные мышцы"), FRONT_DELT("Передние дельты"), BICEPS("Бицепсы"), FOREARM("Предплечья"),
    ABS("Прямая мышца живота"), OBLIQUES("Косые мышцы живота"), QUADS("Квадрицепсы"), CALVES("Икры"),
    TRAPS("Трапеции"), REAR_DELT("Задние дельты"), LATS("Широчайшие мышцы спины"), TRICEPS("Трицепсы"),
    LOWER_BACK("Разгибатели спины"), GLUTES("Ягодицы"), HAMSTRINGS("Бицепсы бёдер")
}

data class Snap(
    val ex: List<ExerciseE> = emptyList(), val programs: List<ProgramE> = emptyList(),
    val planned: List<PlannedE> = emptyList(), val workouts: List<WorkoutE> = emptyList(),
    val wex: List<WExE> = emptyList(), val sets: List<SetE> = emptyList(),
    val kv: Map<String, String> = emptyMap()
)

fun Snap.kvS(k: String, def: String = ""): String = kv[k] ?: def
fun Snap.exOf(id: String): ExerciseE? = ex.firstOrNull { it.id == id }

fun fmt(d: Double): String = if (d % 1.0 == 0.0) d.toInt().toString() else d.toString()

val GOALS = listOf(
    "STRENGTH" to "Развитие силы", "GENERAL" to "Общая физическая форма",
    "ENDURANCE" to "Мышечная выносливость", "BOXING" to "Поддержка бокса", "BALANCED" to "Сбалансированная работа на всё тело"
)
val EXPS = listOf("BEGINNER" to "Новичок", "INTERMEDIATE" to "Средний уровень", "ADVANCED" to "Опытный")
val EQUIP = listOf("BODYWEIGHT" to "Свой вес", "DUMBBELL" to "Гантели", "BAR" to "Турник")
val CATS = listOf("PUSH" to "Жимовые", "PULL" to "Тяговые", "LEGS" to "Ноги", "CORE" to "Кор")
val STATUS_RU = mapOf("ACTIVE" to "Активна", "SAVED" to "Сохранена", "DRAFT" to "Черновик", "PAUSED" to "На паузе", "ARCHIVED" to "В архиве")
fun goalRu(g: String) = GOALS.firstOrNull { it.first == g }?.second ?: g
val WD = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
val MONTHS = listOf("Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек")
val MONTHS_FULL = listOf("Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь")

fun inv(s: String): List<Pair<M, Double>> = s.split(";").mapNotNull {
    val p = it.split(":")
    if (p.size != 2) null else runCatching { M.valueOf(p[0]) to p[1].toDouble() }.getOrNull()
}

// ---------- Program days (JSON) ----------
data class PlanEx(val exId: String, val sets: Int, val reps: Int, val weight: Double, val rest: Int)
data class PDay(val name: String, val weekday: Int, val ex: List<PlanEx>)

fun daysToJson(d: List<PDay>): String {
    val arr = JSONArray()
    for (day in d) {
        val exs = JSONArray()
        for (e in day.ex) exs.put(JSONObject().put("id", e.exId).put("sets", e.sets).put("reps", e.reps).put("w", e.weight).put("rest", e.rest))
        arr.put(JSONObject().put("name", day.name).put("weekday", day.weekday).put("ex", exs))
    }
    return arr.toString()
}

fun daysFromJson(s: String): List<PDay> = runCatching {
    val a = JSONArray(s)
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        val ex = o.getJSONArray("ex")
        PDay(o.getString("name"), o.getInt("weekday"), (0 until ex.length()).map { j ->
            val e = ex.getJSONObject(j)
            PlanEx(e.getString("id"), e.getInt("sets"), e.getInt("reps"), e.getDouble("w"), e.getInt("rest"))
        })
    }
}.getOrDefault(emptyList())

fun ProgramE.days(): List<PDay> = daysFromJson(daysJson)

data class GenReq(
    val age: Int, val exp: String, val goal: String, val equip: Set<String>, val days: List<Int>,
    val minutes: Int, val boxing: List<Int>, val limits: String, val gentle: Boolean
)

data class Draft(
    val id: String, val isNew: Boolean, val name: String, val description: String, val goal: String,
    val exp: String, val sessionMin: Int, val warmup: String, val cooldown: String,
    val days: List<PDay>, val source: String, val status: String, val req: GenReq? = null
)

fun ProgramE.toDraft() = Draft(id, false, name, description, goal, experience, sessionMin, warmup, cooldown, days(), source, status)

// ---------- Scheduling ----------
fun schedule(p: ProgramE, from: Long, weeks: Int): List<PlannedE> {
    val days = p.days()
    val out = ArrayList<PlannedE>()
    for (d in from until from + weeks * 7L) {
        val wd = LocalDate.ofEpochDay(d).dayOfWeek.value
        days.forEachIndexed { i, pd ->
            if (pd.weekday == wd) out.add(PlannedE("${p.id}_${d}_$i", p.id, d, i, pd.name, "PLANNED"))
        }
    }
    return out
}

// ---------- History / records ----------
data class HistEntry(val w: WorkoutE, val sets: List<SetE>)
data class Pr(val maxW: Double, val repsAtMax: Int, val maxReps: Int, val bestVol: Double)

fun history(s: Snap, exId: String, excludeWid: String? = null): List<HistEntry> {
    val setsBy = s.sets.groupBy { it.wexId }
    val wexBy = s.wex.filter { it.exerciseId == exId }.groupBy { it.workoutId }
    return s.workouts.filter { it.status == "DONE" && it.id != excludeWid && wexBy.containsKey(it.id) }
        .sortedWith(compareByDescending<WorkoutE> { it.epochDay }.thenByDescending { it.startedAt })
        .map { w -> HistEntry(w, wexBy[w.id]!!.flatMap { setsBy[it.id] ?: emptyList() }.filter { it.done && it.reps > 0 }.sortedBy { it.idx }) }
        .filter { it.sets.isNotEmpty() }
}

fun prs(h: List<HistEntry>): Pr? {
    val all = h.flatMap { it.sets }
    if (all.isEmpty()) return null
    val maxW = all.maxOf { it.weight }
    return Pr(maxW, all.filter { it.weight == maxW }.maxOf { it.reps }, all.maxOf { it.reps }, all.maxOf { it.reps * it.weight })
}

fun lastWeight(s: Snap, exId: String): Double =
    history(s, exId).firstOrNull()?.sets?.maxOfOrNull { it.weight } ?: 0.0

// ---------- Workload engine ----------
// Set volume = reps * (external kg + bwFactor * bodyKg). Volume is split by involvement coefficients (sum = 1.0).
fun loadsByDay(s: Snap): Map<Long, Map<M, Double>> {
    val bw = s.kvS("weight", "70").toDoubleOrNull() ?: 70.0
    val wexBy = s.wex.groupBy { it.workoutId }
    val setsBy = s.sets.groupBy { it.wexId }
    val res = HashMap<Long, HashMap<M, Double>>()
    for (w in s.workouts) {
        if (w.status != "DONE") continue
        for (x in wexBy[w.id] ?: emptyList()) {
            val e = s.exOf(x.exerciseId) ?: continue
            val vol = (setsBy[x.id] ?: emptyList()).filter { it.done }.sumOf { it.reps * (it.weight + e.bwFactor * bw) }
            if (vol <= 0) continue
            val day = res.getOrPut(w.epochDay) { HashMap() }
            for ((m, c) in inv(e.involvement)) day[m] = (day[m] ?: 0.0) + vol * c
        }
    }
    return res
}

fun periodRange(p: Int): Pair<Long?, Long?> {
    val t = LocalDate.now()
    return when (p) {
        0 -> t.toEpochDay() to t.toEpochDay()
        1 -> t.with(DayOfWeek.MONDAY).toEpochDay() to t.toEpochDay()   // week starts on Monday
        2 -> t.withDayOfMonth(1).toEpochDay() to t.toEpochDay()
        else -> null to null
    }
}

fun loads(byDay: Map<Long, Map<M, Double>>, period: Int): Map<M, Double> {
    val (a, b) = periodRange(period)
    val res = HashMap<M, Double>()
    for ((d, mm) in byDay) {
        if (a != null && d < a) continue
        if (b != null && d > b) continue
        for ((m, v) in mm) res[m] = (res[m] ?: 0.0) + v
    }
    return res
}

data class Rec(val lastDay: Long, val hours: Double, val est: Double) {
    val frac: Double get() = if (est <= 0) 1.0 else min(1.0, hours / est)
}

// Informational estimate only: 54-90 h depending on last-session load vs. average, +24 h if fatigue was reported after it.
fun recovery(s: Snap, byDay: Map<Long, Map<M, Double>>, m: M): Rec? {
    val days = byDay.filter { (it.value[m] ?: 0.0) > 0 }
    if (days.isEmpty()) return null
    val last = days.keys.max()
    val lastLoad = days[last]!![m]!!
    val avg = days.values.map { it[m]!! }.average()
    val ratio = if (avg > 0) (lastLoad / avg).coerceIn(0.5, 1.5) else 1.0
    var est = 36 + 36 * ratio
    val zone = ZoneId.systemDefault()
    val lastMs = LocalDate.ofEpochDay(last).atTime(18, 0).atZone(zone).toInstant().toEpochMilli()
    val fat = s.kvS("fatigueAt", "0").toLongOrNull() ?: 0L
    if (fat > lastMs) est += 24
    val hours = max(0.0, (System.currentTimeMillis() - lastMs) / 3_600_000.0)
    return Rec(last, hours, est)
}

// ---------- Calendar statistics ----------
// Streak = consecutive calendar days with >=1 completed workout. Current streak may end today or yesterday.
fun streaks(days: Set<Long>): Pair<Int, Int> {
    val today = LocalDate.now().toEpochDay()
    var cur = 0
    var d = if (today in days) today else today - 1
    while (d in days) { cur++; d-- }
    var best = 0; var run = 0; var prev = Long.MIN_VALUE
    for (x in days.sorted()) { run = if (x == prev + 1) run + 1 else 1; if (run > best) best = run; prev = x }
    return cur to best
}

data class YearStats(val done: Int, val missed: Int, val rate: Int?, val cur: Int, val best: Int)

// rate = completed / (completed + explicitly missed) within the year
fun yearStats(s: Snap, year: Int): YearStats {
    val a = LocalDate.of(year, 1, 1).toEpochDay(); val b = LocalDate.of(year, 12, 31).toEpochDay()
    val done = s.workouts.count { it.status == "DONE" && it.epochDay in a..b }
    val missed = s.planned.count { it.status == "MISSED" && it.epochDay in a..b }
    val rate = if (done + missed == 0) null else (done * 100.0 / (done + missed)).roundToInt()
    val (c, bst) = streaks(s.workouts.filter { it.status == "DONE" }.map { it.epochDay }.toSet())
    return YearStats(done, missed, rate, c, bst)
}

class CalIdx(s: Snap) {
    val done = HashMap<Long, Int>()
    val missed = HashSet<Long>()
    val planned = HashMap<Long, Int>()
    init {
        s.workouts.filter { it.status == "DONE" }.forEach { done[it.epochDay] = (done[it.epochDay] ?: 0) + 1 }
        s.planned.forEach {
            if (it.status == "MISSED") missed.add(it.epochDay)
            if (it.status == "PLANNED") planned[it.epochDay] = (planned[it.epochDay] ?: 0) + 1
        }
    }
    /** 0 empty, 1 planned, 2 done, 3 missed */
    fun state(d: Long): Int = when {
        done.containsKey(d) -> 2
        missed.contains(d) -> 3
        planned.containsKey(d) -> 1
        else -> 0
    }
}

// ---------- Offline rule-based generator ----------
fun generate(s: Snap, r: GenReq, seed: Long): Draft {
    val rnd = java.util.Random(seed)
    val eq = r.equip + "BODYWEIGHT"
    val lim = r.limits.lowercase()
    val banned = HashSet<String>()
    if (lim.contains("колен")) banned += listOf("lunge", "db_lunge")
    if (lim.contains("плеч")) banned += listOf("pike", "db_ohp", "db_lat_raise", "pushup_dia")
    if (lim.contains("спин") || lim.contains("поясниц")) banned += listOf("db_rdl", "superman")
    if (lim.contains("запяст") || lim.contains("локт")) banned += listOf("pushup_dia", "bench_dip")
    val lib = s.ex.filter { it.equipment in eq && it.id !in banned }
    val used = HashSet<String>()
    fun pick(cat: String, dayUsed: Set<String>): ExerciseE? {
        val c = lib.filter { it.category == cat && it.id !in dayUsed }
        if (c.isEmpty()) return null
        val fresh = c.filter { it.id !in used }
        val pool = if (fresh.isNotEmpty()) fresh else c
        return pool[rnd.nextInt(pool.size)].also { used.add(it.id) }
    }
    var sets = 3; var reps = 10; var rest = 60
    when (r.goal) {
        "STRENGTH" -> { sets = 4; reps = 6; rest = 120 }
        "ENDURANCE" -> { sets = 3; reps = 15; rest = 45 }
        "BOXING" -> { sets = 3; reps = 12; rest = 45 }
    }
    if (r.exp == "BEGINNER") { sets = max(2, sets - 1); reps = max(reps, 8) }
    if (r.age < 16) { sets = min(sets, 3); reps = max(reps, 10); rest = min(rest, 90) }
    if (r.gentle) sets = max(2, sets - 1)
    val ratio = if (r.age < 16) max(1.0, reps / 10.0) else reps / 10.0
    val days = r.days.sorted()
    val n = max(1, days.size)
    val full = listOf("PUSH", "PULL", "LEGS", "CORE", "LEGS", "PUSH", "PULL")
    val upper = listOf("PUSH", "PULL", "PUSH", "PULL", "CORE", "PUSH", "PULL")
    val lower = listOf("LEGS", "LEGS", "LEGS", "CORE", "LEGS", "CORE", "LEGS")
    val baseSlots = (r.minutes / 10).coerceIn(3, 7)
    val out = ArrayList<PDay>()
    var upN = 0; var loN = 0
    days.forEachIndexed { i, wd ->
        val kind: List<String>; val name: String
        if (n <= 3) { kind = full; name = "Всё тело ${'A' + i}" }
        else if (i % 2 == 0) { kind = upper; upN++; name = "Верх $upN" }
        else { kind = lower; loN++; name = "Низ $loN" }
        var slots = baseSlots
        if (wd in r.boxing) slots = max(3, slots - 2)
        val beforeBoxing = ((wd % 7) + 1) in r.boxing
        val dayUsed = HashSet<String>()
        val list = ArrayList<PlanEx>()
        for (k in 0 until slots) {
            var cat = kind[k % kind.size]
            if (beforeBoxing && cat == "LEGS") cat = "CORE"
            val e = pick(cat, dayUsed) ?: continue
            dayUsed.add(e.id)
            val rp = (e.reps * ratio).roundToInt().coerceIn(3, 30)
            val w = if (e.equipment == "DUMBBELL") lastWeight(s, e.id) else 0.0
            list.add(PlanEx(e.id, sets, rp, w, rest))
        }
        out.add(PDay(name, wd, list))
    }
    val notes = ArrayList<String>()
    notes.add("Составлено по правилам (без ИИ) из твоих целей, оборудования и дней.")
    notes.add("Прогрессия: если все подходы выполнены с запасом ~2 повторения — можно добавить 1–2 кг или повторение. Решение всегда за тобой.")
    if (r.age < 16) notes.add("Для юных спортсменов: приоритет — техника и восстановление, без проверки максимума; занимайся под присмотром взрослого или тренера.")
    if (r.boxing.isNotEmpty()) notes.add("Бокс учтён: перед боксёрским днём ноги заменены на кор, в день бокса объём сокращён.")
    val cons = days.zipWithNext().any { (a, b) -> b - a == 1 } || (days.size >= 2 && days.first() == 1 && days.last() == 7)
    if (cons && n <= 3) notes.add("Есть тренировки в соседние дни — следи за самочувствием и при необходимости добавляй день отдыха.")
    if (r.limits.isNotBlank()) notes.add("Учтены ограничения: ${r.limits.trim()}. Это не медицинская рекомендация — при боли остановись и обратись к врачу.")
    if (days.isEmpty()) notes.add("Дни не выбраны — добавь дни вручную.")
    return Draft(
        java.util.UUID.randomUUID().toString(), true, "Программа: ${goalRu(r.goal)}", notes.joinToString("\n"), r.goal, r.exp, r.minutes,
        "5–7 минут: суставная разминка (шея, плечи, локти, запястья, таз, колени), лёгкое кардио, 1–2 лёгких подхода первого упражнения.",
        "3–5 минут: спокойная ходьба, лёгкая растяжка нагруженных мышц, ровное дыхание.",
        out, "RULES", "DRAFT", r
    )
}
