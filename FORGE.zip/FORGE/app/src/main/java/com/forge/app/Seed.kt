package com.forge.app

private fun e(
    id: String, name: String, en: String, cat: String, eq: String, inv: String,
    bw: Double, sets: Int, reps: Int, rest: Int, ins: String
) = ExerciseE(id, name, en, cat, eq, inv, bw, sets, reps, rest, ins, true)

// Involvement coefficients are configurable estimates (sum = 1.0 per exercise), not measurements.
// bwFactor = estimated share of body weight acting as resistance (0 for pure external-load exercises).
val SEED: List<ExerciseE> = listOf(
    e("pushup", "Отжимания", "Push-up", "PUSH", "BODYWEIGHT", "CHEST:0.55;TRICEPS:0.25;FRONT_DELT:0.2", 0.64, 3, 12, 60, "Корпус прямой, локти под углом около 45°. Опускайся плавно, без прогиба в пояснице."),
    e("pushup_inc", "Отжимания от опоры", "Incline push-up", "PUSH", "BODYWEIGHT", "CHEST:0.55;TRICEPS:0.25;FRONT_DELT:0.2", 0.4, 3, 12, 60, "Руки на устойчивой опоре (стол, скамья). Лёгкая версия для освоения техники."),
    e("pushup_dia", "Алмазные отжимания", "Diamond push-up", "PUSH", "BODYWEIGHT", "TRICEPS:0.45;CHEST:0.35;FRONT_DELT:0.2", 0.64, 3, 10, 60, "Ладони рядом под грудью, локти вдоль корпуса."),
    e("pike", "Отжимания «горка»", "Pike push-up", "PUSH", "BODYWEIGHT", "FRONT_DELT:0.5;TRICEPS:0.25;CHEST:0.25", 0.6, 3, 8, 75, "Таз вверх, голова движется между рук. Акцент на плечи."),
    e("bench_dip", "Обратные отжимания от опоры", "Bench dip", "PUSH", "BODYWEIGHT", "TRICEPS:0.6;CHEST:0.2;FRONT_DELT:0.2", 0.5, 3, 10, 60, "Локти назад, не уходи глубоко, плечи не поднимай к ушам."),
    e("pullup", "Подтягивания", "Pull-up", "PULL", "BAR", "LATS:0.5;BICEPS:0.25;FOREARM:0.1;TRAPS:0.1;REAR_DELT:0.05", 1.0, 3, 6, 90, "Лопатки вниз и друг к другу, подбородок выше перекладины, без раскачки."),
    e("superman", "Супермен", "Superman", "PULL", "BODYWEIGHT", "LOWER_BACK:0.55;GLUTES:0.25;REAR_DELT:0.2", 0.3, 3, 12, 45, "Лёжа на животе, поднимай руки и ноги плавно, без рывков."),
    e("squat", "Приседания", "Bodyweight squat", "LEGS", "BODYWEIGHT", "QUADS:0.55;GLUTES:0.35;HAMSTRINGS:0.1", 0.7, 3, 15, 60, "Колени по линии стоп, спина прямая, пятки на полу."),
    e("lunge", "Выпады", "Lunge", "LEGS", "BODYWEIGHT", "QUADS:0.5;GLUTES:0.35;HAMSTRINGS:0.15", 0.7, 3, 10, 60, "Шаг вперёд, корпус вертикально, переднее колено не заваливается внутрь."),
    e("glute_bridge", "Ягодичный мостик", "Glute bridge", "LEGS", "BODYWEIGHT", "GLUTES:0.6;HAMSTRINGS:0.3;LOWER_BACK:0.1", 0.5, 3, 15, 45, "Поднимай таз за счёт ягодиц, вверху короткая пауза."),
    e("calf_raise", "Подъёмы на носки", "Calf raise", "LEGS", "BODYWEIGHT", "CALVES:1.0", 0.9, 3, 20, 45, "Максимальная амплитуда, медленный спуск."),
    e("crunch", "Скручивания", "Crunch", "CORE", "BODYWEIGHT", "ABS:0.7;OBLIQUES:0.3", 0.25, 3, 15, 45, "Поясница прижата, поднимай лопатки, шею не тяни руками."),
    e("bicycle", "Велосипед", "Bicycle crunch", "CORE", "BODYWEIGHT", "OBLIQUES:0.5;ABS:0.5", 0.25, 3, 20, 45, "Медленно, локоть к противоположному колену."),
    e("leg_raise", "Подъём ног лёжа", "Lying leg raise", "CORE", "BODYWEIGHT", "ABS:0.8;OBLIQUES:0.2", 0.3, 3, 12, 45, "Поясница не отрывается от пола, опускай ноги подконтрольно."),
    e("plank", "Планка (1 повтор = 10 с)", "Plank", "CORE", "BODYWEIGHT", "ABS:0.5;OBLIQUES:0.2;LOWER_BACK:0.15;FRONT_DELT:0.15", 0.5, 3, 4, 45, "Тело в одну линию, живот напряжён, дыши ровно."),
    e("bird_dog", "Птица-собака", "Bird dog", "CORE", "BODYWEIGHT", "LOWER_BACK:0.5;GLUTES:0.3;ABS:0.2", 0.2, 3, 10, 45, "Тяни противоположные руку и ногу, таз не вращается."),
    e("db_press", "Жим гантелей лёжа", "Dumbbell bench press", "PUSH", "DUMBBELL", "CHEST:0.6;TRICEPS:0.2;FRONT_DELT:0.2", 0.0, 3, 10, 90, "Лопатки сведены, гантели по дуге вверх, опускай до комфортного растяжения груди."),
    e("db_fly", "Разведение гантелей лёжа", "Dumbbell fly", "PUSH", "DUMBBELL", "CHEST:0.8;FRONT_DELT:0.2", 0.0, 3, 12, 60, "Локти слегка согнуты, лёгкий вес, без глубокого провала."),
    e("db_ohp", "Жим гантелей стоя", "Dumbbell overhead press", "PUSH", "DUMBBELL", "FRONT_DELT:0.5;TRICEPS:0.3;TRAPS:0.2", 0.0, 3, 10, 90, "Корпус жёсткий, не прогибай поясницу."),
    e("db_lat_raise", "Подъём гантелей в стороны", "Lateral raise", "PUSH", "DUMBBELL", "FRONT_DELT:0.5;REAR_DELT:0.3;TRAPS:0.2", 0.0, 3, 12, 60, "Лёгкий вес, локти чуть выше кистей, без рывков. (Боковая дельта в карте не выделена, нагрузка распределена оценочно.)"),
    e("db_tri_ext", "Разгибание руки из-за головы", "Overhead triceps extension", "PUSH", "DUMBBELL", "TRICEPS:1.0", 0.0, 3, 12, 60, "Локти смотрят вперёд и не разъезжаются."),
    e("db_row", "Тяга гантели в наклоне", "One-arm dumbbell row", "PULL", "DUMBBELL", "LATS:0.5;BICEPS:0.2;REAR_DELT:0.15;TRAPS:0.15", 0.0, 3, 10, 75, "Спина ровная, тяни локоть к тазу."),
    e("db_rdelt", "Разведение гантелей в наклоне", "Rear delt fly", "PULL", "DUMBBELL", "REAR_DELT:0.6;TRAPS:0.3;LATS:0.1", 0.0, 3, 12, 60, "Лёгкий вес, сводим лопатки в конце движения."),
    e("db_shrug", "Шраги с гантелями", "Dumbbell shrug", "PULL", "DUMBBELL", "TRAPS:0.8;FOREARM:0.2", 0.0, 3, 12, 60, "Поднимай плечи вертикально, без вращений."),
    e("db_curl", "Сгибание рук с гантелями", "Dumbbell curl", "PULL", "DUMBBELL", "BICEPS:0.75;FOREARM:0.25", 0.0, 3, 12, 60, "Локти прижаты, без раскачки корпусом."),
    e("db_hammer", "Молотковые сгибания", "Hammer curl", "PULL", "DUMBBELL", "BICEPS:0.55;FOREARM:0.45", 0.0, 3, 12, 60, "Нейтральный хват, плавный спуск."),
    e("db_pullover", "Пуловер с гантелью", "Dumbbell pullover", "PULL", "DUMBBELL", "LATS:0.5;CHEST:0.3;TRICEPS:0.2", 0.0, 3, 12, 60, "Небольшой вес, амплитуда без боли в плечах."),
    e("db_goblet", "Гоблет-присед", "Goblet squat", "LEGS", "DUMBBELL", "QUADS:0.5;GLUTES:0.35;HAMSTRINGS:0.1;LOWER_BACK:0.05", 0.7, 3, 12, 75, "Гантель у груди, корпус прямой, глубина по комфорту."),
    e("db_rdl", "Румынская тяга с гантелями", "Dumbbell Romanian deadlift", "LEGS", "DUMBBELL", "HAMSTRINGS:0.4;GLUTES:0.35;LOWER_BACK:0.25", 0.0, 3, 10, 90, "Таз назад, спина нейтральная, гантели скользят вдоль ног."),
    e("db_lunge", "Выпады с гантелями", "Dumbbell lunge", "LEGS", "DUMBBELL", "QUADS:0.45;GLUTES:0.35;HAMSTRINGS:0.2", 0.7, 3, 10, 75, "Гантели по бокам, шаг достаточно длинный, корпус вертикально."),
    e("db_calf", "Подъёмы на носки с гантелями", "Dumbbell calf raise", "LEGS", "DUMBBELL", "CALVES:1.0", 0.9, 3, 15, 45, "Держись за опору, полная амплитуда."),
    e("db_russian", "Русские скручивания с гантелью", "Russian twist", "CORE", "DUMBBELL", "OBLIQUES:0.6;ABS:0.4", 0.25, 3, 16, 45, "Спина ровная, вращай корпус, а не только руки.")
)
