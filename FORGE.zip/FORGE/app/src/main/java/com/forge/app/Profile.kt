package com.forge.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ProfileScreen(vm: AppVm) {
    val s by vm.snap.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingRestore by remember { mutableStateOf<String?>(null) }

    val saveJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.backupJson().toByteArray()) } ?: error("нет доступа") }.isSuccess }
            vm.message = if (ok) "Резервная копия сохранена" else "Не удалось сохранить файл"
        }
    }
    val saveCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.csv().toByteArray()) } ?: error("нет доступа") }.isSuccess }
            vm.message = if (ok) "CSV сохранён" else "Не удалось сохранить файл"
        }
    }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val txt = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } }.getOrNull() }
            if (txt == null) vm.message = "Не удалось прочитать файл"
            else try { parseBackup(txt); pendingRestore = txt } catch (e: IllegalArgumentException) { vm.message = e.message }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Wordmark(); H1("Профиль")
        TF(s.kvS("name"), { vm.setKv("name", it) }, "Имя или ник")
        TF(s.kvS("age"), { vm.setKv("age", it.filter { c -> c.isDigit() }) }, "Возраст", number = true)
        TF(s.kvS("weight"), { vm.setKv("weight", it.replace(',', '.')) }, "Вес тела, кг (для оценки нагрузки в упражнениях со своим весом)")
        Drop("Опыт", EXPS, s.kvS("exp", "BEGINNER"), { vm.setKv("exp", it) })
        Drop("Главная цель", GOALS, s.kvS("goal", "GENERAL"), { vm.setKv("goal", it) })
        H2("Доступное оборудование")
        val eq = s.kvS("equip", "BODYWEIGHT").split(",").filter { it.isNotBlank() }.toSet() + "BODYWEIGHT"
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            EQUIP.forEach { (k, v) -> Chip(v, k in eq, { if (k != "BODYWEIGHT") vm.setKv("equip", (if (k in eq) eq - k else eq + k).joinToString(",")) }) }
        }
        Sec("Единицы: килограммы. Тема: тёмная. Регистрация не требуется, данные хранятся только на телефоне.", 12, color = C.muted)
        HorizontalDivider(color = C.border)
        H2("ИИ-сервер")
        TF(s.kvS("aiUrl"), { vm.setKv("aiUrl", it) }, "Адрес сервера (https://…)")
        Sec(if (s.kvS("aiUrl").isBlank()) "Не настроен: доступен офлайн-генератор по правилам. Ключи API в приложении не хранятся — сервер описан в README." else "Адрес указан. Результат проверяется перед показом; при ошибке будет сообщение.", 12)
        HorizontalDivider(color = C.border)
        H2("Данные")
        FBtn("Экспорт резервной копии (JSON)", { saveJson.launch("forge-backup.json") }, Modifier.fillMaxWidth(), primary = false)
        FBtn("Экспорт истории (CSV)", { saveCsv.launch("forge-history.csv") }, Modifier.fillMaxWidth(), primary = false)
        FBtn("Восстановить из копии", { open.launch(arrayOf("application/json", "text/plain", "*/*")) }, Modifier.fillMaxWidth(), primary = false)
        Sec("Напоминания и облачная синхронизация не реализованы.", 12, color = C.muted)
        Spacer(Modifier.height(16.dp))
    }
    pendingRestore?.let { txt ->
        Confirm("Заменить данные?", "Файл корректен. Все текущие данные приложения будут заменены данными из копии.", "Восстановить", {
            pendingRestore = null
            scope.launch { val e = vm.restore(txt); vm.message = e ?: "Данные восстановлены" }
        }, { pendingRestore = null })
    }
}
