package com.forge.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun DayCell(st: Int, today: Boolean, selected: Boolean, size: Dp, onClick: () -> Unit) {
    val shape = RoundedCornerShape(3.dp)
    val fill = when (st) { 2 -> C.mint; 3 -> C.coral; 1 -> C.mintDark; else -> Color.Transparent }
    val bc = when {
        today -> C.text; selected -> C.mint
        st == 1 -> C.mint.copy(alpha = 0.6f); st == 2 -> C.mint; st == 3 -> C.coral
        else -> C.border
    }
    Box(Modifier.size(size).clip(shape).background(fill).border(if (today || selected) 1.5.dp else 1.dp, bc, shape).clickable(onClick = onClick))
}

@Composable
fun CalendarScreen(vm: AppVm, onSettings: () -> Unit) {
    val s by vm.snap.collectAsState()
    val now = LocalDate.now()
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var year by rememberSaveable { mutableIntStateOf(now.year) }
    var month by rememberSaveable { mutableIntStateOf(now.monthValue) }
    var weekStart by rememberSaveable { mutableLongStateOf(now.with(DayOfWeek.MONDAY).toEpochDay()) }
    var sel by rememberSaveable { mutableStateOf<Long?>(null) }
    val idx = remember(s.workouts, s.planned) { CalIdx(s) }
    val todayD = now.toEpochDay()
    val st = remember(s.workouts, s.planned, year) { yearStats(s, year) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Wordmark(); Spacer(Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Профиль", tint = C.sec) }
        }
        H1("Календарь тренировок")
        Seg(listOf("Год", "Месяц", "Неделя"), mode, { mode = it })
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                when (mode) { 0 -> year--; 1 -> { if (month == 1) { month = 12; year-- } else month-- }; else -> weekStart -= 7 }
            }) { Icon(Icons.Default.ChevronLeft, "Назад", tint = C.text) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                val title = when (mode) {
                    0 -> "$year"
                    1 -> "${MONTHS_FULL[month - 1]} $year"
                    else -> LocalDate.ofEpochDay(weekStart).let { a -> val b = a.plusDays(6); "${a.dayOfMonth} ${MONTHS[a.monthValue - 1]} – ${b.dayOfMonth} ${MONTHS[b.monthValue - 1]}" }
                }
                Text(title, fontSize = 26.sp, fontFamily = FontFamily.Serif, color = C.sec)
                Sec("Выполнено тренировок: ${st.done}", 12)
            }
            IconButton(onClick = {
                when (mode) { 0 -> year++; 1 -> { if (month == 12) { month = 1; year++ } else month++ }; else -> weekStart += 7 }
            }) { Icon(Icons.Default.ChevronRight, "Вперёд", tint = C.text) }
        }

        when (mode) {
            0 -> {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (m in 1..12) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Sec(MONTHS[m - 1], 11, Modifier.padding(bottom = 4.dp))
                            val len = YearMonth.of(year, m).lengthOfMonth()
                            for (r in 0 until 16) {
                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    for (c in 0..1) {
                                        val dn = r * 2 + c + 1
                                        if (dn <= len) {
                                            val d = LocalDate.of(year, m, dn).toEpochDay()
                                            DayCell(idx.state(d), d == todayD, d == sel, 13.dp) { sel = d }
                                        } else Spacer(Modifier.size(13.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                val first = LocalDate.of(year, month, 1)
                val off = first.dayOfWeek.value - 1
                val len = first.lengthOfMonth()
                Row { WD.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp, color = C.muted) } }
                for (r in 0 until (off + len + 6) / 7) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                        for (c in 0..6) {
                            val dn = r * 7 + c - off + 1
                            if (dn in 1..len) {
                                val d = LocalDate.of(year, month, dn).toEpochDay()
                                val stt = idx.state(d)
                                val shape = RoundedCornerShape(6.dp)
                                val fill = when (stt) { 2 -> C.mint; 3 -> C.coral; 1 -> C.mintDark; else -> Color.Transparent }
                                Box(
                                    Modifier.weight(1f).height(44.dp).clip(shape).background(fill)
                                        .border(if (d == todayD) 1.5.dp else 1.dp, if (d == todayD) C.text else if (stt == 0) C.border else fill, shape)
                                        .clickable { sel = d }, contentAlignment = Alignment.Center
                                ) { Text("$dn", fontSize = 14.sp, color = if (stt == 2 || stt == 3) C.bg else C.text) }
                            } else Spacer(Modifier.weight(1f).height(44.dp))
                        }
                    }
                }
            }
            else -> {
                for (i in 0..6) {
                    val d = weekStart + i
                    val date = LocalDate.ofEpochDay(d)
                    val pl = s.planned.filter { it.epochDay == d && it.status == "PLANNED" }
                    val ws = s.workouts.filter { it.epochDay == d && it.status == "DONE" }
                    val stt = idx.state(d)
                    Card(onClick = { sel = d }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.width(56.dp)) {
                                Text(WD[i], color = if (d == todayD) C.mint else C.text, fontSize = 15.sp)
                                Sec("${date.dayOfMonth} ${MONTHS[date.monthValue - 1]}", 12)
                            }
                            Column(Modifier.weight(1f)) {
                                if (ws.isEmpty() && pl.isEmpty()) Sec(if (stt == 3) "Пропущена" else "День отдыха / нет записей", 13)
                                ws.forEach { Text("✓ ${it.name}", color = C.mint, fontSize = 14.sp) }
                                pl.forEach { Text("◦ ${it.dayName} (план)", color = C.text, fontSize = 14.sp) }
                            }
                            DayCell(stt, d == todayD, false, 14.dp) { sel = d }
                        }
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Legend(C.mint, "Выполнена"); Legend(C.coral, "Пропущена"); Legend(C.mintDark, "В плане"); Legend(Color.Transparent, "Нет записи")
        }
        HorizontalDivider(color = C.border)
        H2("Годовая статистика")
        Row(Modifier.fillMaxWidth()) {
            Stat("${st.done}", "Тренировок", Modifier.weight(1f))
            Stat(st.rate?.let { "$it%" } ?: "—", "Успешность", Modifier.weight(1f))
            Stat("${st.missed}", "Пропусков", Modifier.weight(1f))
            Stat("${st.cur}", "Серия, дн.", Modifier.weight(1f))
            Stat("${st.best}", "Лучшая", Modifier.weight(1f))
        }
        Sec("Успешность = выполненные / (выполненные + отмеченные пропущенными). Серия — подряд идущие календарные дни с тренировкой.", 11, color = C.muted)
        Spacer(Modifier.height(8.dp))
    }
    sel?.let { DaySheet(vm, s, it) { sel = null } }
}

@Composable
fun Legend(c: Color, t: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(c).border(1.dp, if (c == Color.Transparent) C.border else c, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(4.dp)); Sec(t, 11)
    }
}

@Composable
fun Stat(v: String, l: String, modifier: Modifier = Modifier) = Column(modifier) {
    Text(v, fontSize = 22.sp, fontFamily = FontFamily.Serif, color = C.text)
    Sec(l, 11)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DaySheet(vm: AppVm, s: Snap, day: Long, onDismiss: () -> Unit) {
    val date = LocalDate.ofEpochDay(day)
    val planned = s.planned.filter { it.epochDay == day }
    val ws = s.workouts.filter { it.epochDay == day }.sortedBy { it.startedAt }
    var move by remember { mutableStateOf<PlannedE?>(null) }
    var del by remember { mutableStateOf<WorkoutE?>(null) }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = C.bg2) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            H1("${date.dayOfMonth} ${MONTHS_FULL[date.monthValue - 1].lowercase()} ${date.year}")
            if (planned.isEmpty() && ws.isEmpty()) Sec("На этот день ничего нет. День отдыха не считается пропуском.")
            planned.forEach { p ->
                Card {
                    val prog = s.programs.firstOrNull { it.id == p.programId }?.name ?: "программа удалена"
                    Text(p.dayName, color = C.text, fontSize = 16.sp)
                    Sec("Программа: $prog · " + when (p.status) { "PLANNED" -> "запланирована"; "DONE" -> "выполнена"; "MISSED" -> "пропущена"; else -> "пропущена без учёта" }, 12)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (p.status == "PLANNED") {
                            FBtn("Начать", { vm.startPlanned(p); onDismiss() })
                            FBtn("Пропущена", { vm.setPlannedStatus(p, "MISSED") }, primary = false)
                            FBtn("Пропустить", { vm.setPlannedStatus(p, "SKIPPED") }, primary = false)
                            FBtn("Перенести", { move = p }, primary = false)
                        } else if (p.status != "DONE") FBtn("Вернуть в план", { vm.setPlannedStatus(p, "PLANNED") }, primary = false)
                    }
                }
            }
            ws.forEach { w ->
                val xs = s.wex.filter { it.workoutId == w.id }.sortedBy { it.ord }
                Card(onClick = { vm.push(Ov.Session(w.id)); onDismiss() }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(w.name, color = C.text, fontSize = 16.sp)
                            Sec(if (w.status == "ACTIVE") "идёт сейчас" else "выполнена" + if (w.durationSec > 0) " · ${w.durationSec / 60} мин" else "", 12)
                        }
                        IconButton(onClick = { del = w }) { Icon(Icons.Default.Delete, "Удалить", tint = C.sec) }
                    }
                    xs.forEach { x ->
                        val ss = s.sets.filter { it.wexId == x.id && it.done }
                        Sec("${x.name}: " + if (ss.isEmpty()) "нет выполненных подходов" else ss.joinToString(", ") { "${it.reps}×${fmt(it.weight)}" }, 12)
                    }
                    if (w.note.isNotBlank()) Sec("Заметка: ${w.note}", 12, color = C.muted)
                }
            }
            FBtn("Добавить тренировку", { vm.startFree(day); onDismiss() }, Modifier.fillMaxWidth(), primary = false)
        }
    }
    move?.let { p ->
        val ds = rememberDatePickerState(initialSelectedDateMillis = p.epochDay * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { move = null },
            confirmButton = { TextButton(onClick = { ds.selectedDateMillis?.let { vm.movePlanned(p, it / 86_400_000L) }; move = null }) { Text("Перенести") } },
            dismissButton = { TextButton(onClick = { move = null }) { Text("Отмена") } }
        ) { DatePicker(state = ds) }
    }
    del?.let { w ->
        Confirm("Удалить тренировку?", "Запись «${w.name}» будет удалена, статистика и карта мышц пересчитаются.", "Удалить", { vm.deleteWorkout(w.id); del = null }, { del = null })
    }
}
