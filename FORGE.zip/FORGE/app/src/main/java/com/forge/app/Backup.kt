package com.forge.app

import org.json.JSONArray
import org.json.JSONObject
import java.lang.reflect.Modifier

val TABLES: List<Pair<String, Class<*>>> = listOf(
    "exercises" to ExerciseE::class.java, "programs" to ProgramE::class.java, "planned" to PlannedE::class.java,
    "workouts" to WorkoutE::class.java, "wexercises" to WExE::class.java, "sets" to SetE::class.java, "kv" to KvE::class.java
)

private fun fieldsOf(c: Class<*>) = c.declaredFields.filter { !Modifier.isStatic(it.modifiers) && !it.isSynthetic }

fun rowToJson(o: Any): JSONObject {
    val j = JSONObject()
    for (f in fieldsOf(o.javaClass)) { f.isAccessible = true; j.put(f.name, f.get(o)) }
    return j
}

fun rowFromJson(c: Class<*>, j: JSONObject): Any {
    val fs = fieldsOf(c)
    val args = fs.map { f ->
        when (f.type) {
            String::class.java -> j.getString(f.name)
            java.lang.Long.TYPE -> j.getLong(f.name)
            Integer.TYPE -> j.getInt(f.name)
            java.lang.Double.TYPE -> j.getDouble(f.name)
            java.lang.Boolean.TYPE -> j.getBoolean(f.name)
            else -> throw IllegalArgumentException("type")
        }
    }.toTypedArray()
    val ctor = c.declaredConstructors.first { it.parameterCount == fs.size && !it.isSynthetic }
    return ctor.newInstance(*args)
}

fun exportJson(s: Snap): String {
    val root = JSONObject().put("app", "FORGE").put("version", 1).put("exportedAt", System.currentTimeMillis())
    val t = JSONObject()
    t.put("exercises", JSONArray(s.ex.map { rowToJson(it) }))
    t.put("programs", JSONArray(s.programs.map { rowToJson(it) }))
    t.put("planned", JSONArray(s.planned.map { rowToJson(it) }))
    t.put("workouts", JSONArray(s.workouts.map { rowToJson(it) }))
    t.put("wexercises", JSONArray(s.wex.map { rowToJson(it) }))
    t.put("sets", JSONArray(s.sets.map { rowToJson(it) }))
    t.put("kv", JSONArray(s.kv.map { rowToJson(KvE(it.key, it.value)) }))
    root.put("tables", t)
    return root.toString(1)
}

class Parsed(val tables: Map<String, List<Any>>)

/** Validates fully before anything touches the database. Returns Parsed or throws with a Russian message. */
fun parseBackup(text: String): Parsed {
    val root = try { JSONObject(text) } catch (e: Exception) { throw IllegalArgumentException("Файл не является корректным JSON") }
    if (root.optString("app") != "FORGE") throw IllegalArgumentException("Это не резервная копия FORGE")
    if (root.optInt("version", 0) != 1) throw IllegalArgumentException("Неподдерживаемая версия копии")
    val t = root.optJSONObject("tables") ?: throw IllegalArgumentException("В файле нет таблиц данных")
    val out = HashMap<String, List<Any>>()
    for ((name, cls) in TABLES) {
        val a = t.optJSONArray(name) ?: throw IllegalArgumentException("Нет таблицы «$name»")
        out[name] = try { (0 until a.length()).map { rowFromJson(cls, a.getJSONObject(it)) } }
        catch (e: Exception) { throw IllegalArgumentException("Повреждены данные в таблице «$name»") }
    }
    @Suppress("UNCHECKED_CAST")
    val wids = (out["workouts"] as List<WorkoutE>).map { it.id }.toSet()
    @Suppress("UNCHECKED_CAST")
    val wex = out["wexercises"] as List<WExE>
    if (wex.any { it.workoutId !in wids }) throw IllegalArgumentException("Упражнения ссылаются на несуществующие тренировки")
    val xids = wex.map { it.id }.toSet()
    @Suppress("UNCHECKED_CAST")
    if ((out["sets"] as List<SetE>).any { it.wexId !in xids }) throw IllegalArgumentException("Подходы ссылаются на несуществующие упражнения")
    return Parsed(out)
}

fun exportCsv(s: Snap): String {
    val sb = StringBuilder("date,workout,exercise,set,reps,weight_kg,done\n")
    val wexBy = s.wex.groupBy { it.workoutId }
    val setsBy = s.sets.groupBy { it.wexId }
    for (w in s.workouts.filter { it.status == "DONE" }.sortedBy { it.epochDay }) {
        for (x in (wexBy[w.id] ?: emptyList()).sortedBy { it.ord }) {
            for (st in (setsBy[x.id] ?: emptyList()).sortedBy { it.idx }) {
                sb.append(java.time.LocalDate.ofEpochDay(w.epochDay)).append(',')
                    .append('"').append(w.name.replace("\"", "\"\"")).append('"').append(',')
                    .append('"').append(x.name.replace("\"", "\"\"")).append('"').append(',')
                    .append(st.idx + 1).append(',').append(st.reps).append(',').append(fmt(st.weight)).append(',').append(st.done).append('\n')
            }
        }
    }
    return sb.toString()
}
