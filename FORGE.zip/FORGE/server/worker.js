// Cloudflare Worker (free tier) — proxy between the FORGE app and Anthropic API.
// Secrets: ANTHROPIC_API_KEY (wrangler secret put ANTHROPIC_API_KEY). Optional var MODEL.
export default {
  async fetch(request, env) {
    if (request.method !== "POST") return new Response("POST only", { status: 405 });
    let req;
    try { req = await request.json(); } catch { return new Response("bad json", { status: 400 }); }
    if (!Array.isArray(req.days) || !Array.isArray(req.exercises) || req.days.length < 1 || req.days.length > 7)
      return new Response("invalid request", { status: 400 });
    const prompt =
`Составь программу тренировок. Отвечай ТОЛЬКО JSON без пояснений и markdown.
Схема: {"name":str,"description":str,"warmup":str,"cooldown":str,"days":[{"name":str,"weekday":1-7,"exercises":[{"exId":str,"sets":int,"reps":int,"weight":number,"rest":int}]}]}
Правила: используй только exId из списка; дни недели строго из ${JSON.stringify(req.days)} (1=Пн); без тренажёров;
учитывай бокс в днях ${JSON.stringify(req.boxingDays || [])} (не нагружай ноги накануне); не ставь одинаковые мышцы в соседние дни;
возраст ${req.age}${req.age < 16 ? " — юный спортсмен: техника, без максимумов, умеренный объём" : ""}; опыт ${req.experience}; цель ${req.goal};
длительность ${req.minutes} мин; ограничения: ${String(req.limits || "нет").slice(0, 300)}; пониженный объём: ${!!req.gentle}.
Вес weight = 0, если нет данных. Упражнения: ${JSON.stringify(req.exercises)}`;
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: env.MODEL || "claude-sonnet-5-5", max_tokens: 4000, messages: [{ role: "user", content: prompt }] })
    });
    if (!r.ok) return new Response("upstream error", { status: 502 });
    const data = await r.json();
    const text = (data.content || []).map(c => c.text || "").join("").replace(/```json|```/g, "").trim();
    try { JSON.parse(text); } catch { return new Response("model returned invalid JSON", { status: 502 }); }
    return new Response(text, { headers: { "content-type": "application/json" } });
  }
};
